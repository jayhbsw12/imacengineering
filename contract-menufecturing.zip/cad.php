<style>
  :root {
  --default-font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    Ubuntu, "Helvetica Neue", Helvetica, Arial, "PingFang SC",
    "Hiragino Sans GB", "Microsoft Yahei UI", "Microsoft Yahei",
    "Source Han Sans CN", sans-serif;
  --primary-color: #ff4612;
  --text-dark: #151515;
  --text-medium: #24282b;
  --text-light: #262d3d;
  --white: #ffffff;
  --overlay-light: rgba(237, 241, 253, 0.2);
}

.service-section {
  position: relative;
  width: 100%;
  height: 1000px;
  overflow: hidden;
}

.service-background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
}

.hero-bg-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.service-content-banner {
  position: relative;
  z-index: 2;
  padding: 72px 100px 0;
  max-width: 1200px;
}

.breadcrumb {
  margin-bottom: 15px;
}

.breadcrumb-text {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 326px;
  height: 30px;
  color: var(--white);
  font-family: 'Poppins', var(--default-font-family);
  font-size: 18px;
  font-weight: 400;
  line-height: 30px;
  text-align: center;
  white-space: nowrap;
}

.divider-line {
  margin-bottom: 33px;
}

.divider-line img {
  width: 991px;
  height: 1px;
}

.banner-header {
  margin-bottom: 50px;
}

.banner-title {
  color: var(--white);
  font-family: 'Inter', var(--default-font-family);
  font-size: 50px;
  font-weight: 700;
  line-height: 60.5px;
  text-align: left;
  text-transform: uppercase;
  margin-bottom: 35px;
  white-space: nowrap;
}

.banner-description {
  width: 881px;
  height: auto;
  color: var(--white);
  font-family: 'Poppins', var(--default-font-family);
  font-size: 18px;
  font-weight: 400;
  line-height: 30px;
  text-align: left;
}


.service-main-container {
  position: relative;
  width: 100%;
  min-height: 100vh;
  background: var(--white);
  overflow: hidden;
}

.cta-button {
  position: absolute;
  bottom: 492px;
  left: 100px;
  width: 219px;
  height: 43px;
  background: var(--primary-color);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.cta-button:hover {
  background: #e63d0f;
}

.cta-text {
  color: var(--white);
  font-family: 'Inter', var(--default-font-family);
  font-size: 16px;
  font-weight: 500;
  line-height: 19px;
  text-align: left;
  white-space: nowrap;
  margin-right: 39px;
}

.cta-arrow {
  width: 16px;
  height: 14px;
}

/* banner Testimonial css */

.banner-testimonial-slider {
  position: absolute;
  top: 72px;
  right: 104px;
  width: 507px;
  height: 729px;
  z-index: 3;
}

.banner-testimonial-card {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}

.banner-testimonial-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.banner-testimonial-content {
  position: absolute;
  bottom: 0;
  background: var(--white);
  padding: 32px;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: 18px;
}


.testimonial-text-container {
  height: 92px;
}

.banner-testimonial-text {
  font-size: 16px;
  font-weight: 400;
  color: var(--text-light);
  line-height: 24px;
}

.testimonial-author-name {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-light);
}

.profile-image {
  width: 60px;
  height: 60px;
  object-fit: cover;
}

.testimonial-dots {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  margin-top: 24px;
}

.testimonial-dots .dot {
  width: 32px;
  height: 3px;
  background-color:rgb(60 36 36 / 30%);
  border-radius: 3px;
  transition: background-color 0.3s ease;
}

.testimonial-dots .dot.active {
  background-color: var(--primary-color);
}


.testimonial-overlay {
  position: absolute;
  height: 2px;
  bottom: 48px;
  left: 16px;
  right: 16px;
  background: rgba(255, 255, 255, 0.4);
  z-index: 3;
}

/* Testimonial slider animation */
/* .testimonial-card {
  animation: testimonialFade 15s infinite;
} */

@keyframes testimonialFade {
  0%, 30% { opacity: 1; }
  33%, 97% { opacity: 0.7; }
  100% { opacity: 1; }
}

</style>
 <main class="service-main-container">
  <!-- Hero + Testimonial + Logo Section Combined -->
  <section class="service-section">
    <!-- Background -->
    <div class="service-background">
      <img src="https://static.codia.ai/custom_image/2025-07-05/131851/hero-background.png" alt="Hero Background" class="hero-bg-image">
    </div>

    <!-- Hero Content -->
    <div class="service-content-banner">
      <nav class="breadcrumb">
        <span class="breadcrumb-text">Services / CAD Outsourcing Services</span>
      </nav>

      <div class="divider-line">
        <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>

      <header class="banner-header">
        <h1 class="banner-title">Mechanical CAD Drafting Services</h1>
        <p class="banner-description">
          iMAC Design and Engineering Services specializes in mechanical drawings, machine designs, assembly and part drawings, and conceptual layouts etc. With a focus on global standards and client requirements, we deliver precision-excellent CAD outsourcing solutions. Trusted by 100+ companies worldwide, we help you reduce project timelines with distinction while exceeding client expectations.
        </p>
      </header>

      <div class="cta-button">
        <span class="cta-text">Get your Quote Now</span>
        <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow">
      </div>
    </div>

    <!-- Testimonial Slider -->
    <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
        <div class="banner-testimonial-image">
          <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
        </div>
        <div class="banner-testimonial-content">
          <div class="banner-testimonial-text-container">
            <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
          </div>
          <div class="banner-testimonial-author">
            <span class="testimonial-author-name">Meli Pattern Works</span>
          </div>
          <div class="banner-testimonial-profile">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
          </div>
          <div class="testimonial-dots">
            <div class="dot active"></div>
            <div class="dot"></div>
            <div class="dot"></div>
          </div>
        </div>
        <div class="testimonial-overlay"></div>
      </div>
    </aside>

    <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
  <div class="logo-flex-wrapper">
    <div class="banner-logo-header">
      <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
    </div>
    <div class="banner-logo-slider">
      <div class="banner-logo-track">
        <!-- Logo Items -->
        <div class="banner-logo-item">
          <div class="banner-logo-wrapper">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
          </div>
        </div>
        <div class="banner-logo-item">
          <div class="banner-logo-wrapper">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
          </div>
        </div>
        <div class="banner-logo-item">
          <div class="banner-logo-wrapper">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
          </div>
        </div>
        <!-- Duplicate logos for infinite scroll -->
        <div class="banner-logo-item">
          <div class="banner-logo-wrapper">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
          </div>
        </div>
        <div class="banner-logo-item">
          <div class="banner-logo-wrapper">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
          </div>
        </div>
        <div class="banner-logo-item">
          <div class="banner-logo-wrapper">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  </section>
<!-- contact section end -->
<script>
  // Main JavaScript file for initialization and common functionality
document.addEventListener('DOMContentLoaded', function() {
  // Initialize all components
  initializeLogoSlider();
  initializeTestimonialSlider();
  initializeScrollEffects();
  initializeCTAButton();
});

// Smooth scroll for internal links
function initializeScrollEffects() {
  // Add smooth scrolling behavior
  const links = document.querySelectorAll('a[href^="#"]');
  
  links.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      if (targetSection) {
        targetSection.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
}

// CTA Button functionality
function initializeCTAButton() {
  const ctaButton = document.querySelector('.cta-button');
  
  if (ctaButton) {
    ctaButton.addEventListener('click', function() {
      // Add your CTA functionality here
      console.log('CTA button clicked');
      
      // Example: Open contact form or redirect
      // window.location.href = '/contact';
      
      // Add click animation
      this.style.transform = 'scale(0.95)';
      setTimeout(() => {
        this.style.transform = 'scale(1)';
      }, 150);
    });
    
    // Add hover effects
    ctaButton.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-2px)';
      this.style.boxShadow = '0 4px 12px rgba(255, 70, 18, 0.3)';
    });
    
    ctaButton.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = 'none';
    });
  }
}

// Utility function for responsive behavior
function handleResize() {
  const width = window.innerWidth;
  
  // Adjust logo slider speed based on screen size
  const logoTrack = document.querySelector('.logo-track');
  if (logoTrack) {
    if (width < 768) {
      logoTrack.style.animationDuration = '15s';
    } else if (width < 1200) {
      logoTrack.style.animationDuration = '18s';
    } else {
      logoTrack.style.animationDuration = '20s';
    }
  }
}

// Listen for window resize
window.addEventListener('resize', handleResize);

// Initialize on load
handleResize();


// Testimonial Slider functionality
function initializeTestimonialSlider() {
  const testimonialData = [
    {
      text: "I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...",
      author: "Meli Pattern Works",
      image: "https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png"
    },
    {
      text: "Outstanding CAD drafting services with exceptional attention to detail. The team delivered exactly what we needed for our manufacturing process.",
      author: "TechFlow Industries",
      image: "https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png"
    },
    {
      text: "Professional service and quick turnaround time. iMAC Design helped us convert our legacy drawings to modern 3D models efficiently.",
      author: "Precision Manufacturing Co.",
      image: "https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png"
    }
  ];

  let currentTestimonial = 0;
  const testimonialText = document.querySelector('.banner-testimonial-text');
  const authorName = document.querySelector('.testimonial-author-name');
  const profileImage = document.querySelector('.profile-image');
  const dots = document.querySelectorAll('.dot');

  function updateTestimonial(index) {
    if (!testimonialText || !authorName || !profileImage) return;

    testimonialText.style.opacity = '0';
    authorName.style.opacity = '0';

    setTimeout(() => {
      testimonialText.textContent = testimonialData[index].text;
      authorName.textContent = testimonialData[index].author;
      profileImage.src = testimonialData[index].image;

      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
      });

      testimonialText.style.opacity = '1';
      authorName.style.opacity = '1';
    }, 300);
  }

  function nextTestimonial() {
    currentTestimonial = (currentTestimonial + 1) % testimonialData.length;
    updateTestimonial(currentTestimonial);
  }

  setInterval(nextTestimonial, 5000);

  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      currentTestimonial = index;
      updateTestimonial(currentTestimonial);
    });
  });

  if (testimonialText) {
    testimonialText.style.transition = 'opacity 0.3s ease';
  }
  if (authorName) {
    authorName.style.transition = 'opacity 0.3s ease';
  }

  updateTestimonial(0);
}

// Touch/swipe support for mobile
function addSwipeSupport() {
  const testimonialCard = document.querySelector('.banner-testimonial-card');
  if (!testimonialCard) return;

  let startX = 0;
  let startY = 0;

  testimonialCard.addEventListener('touchstart', function(e) {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  });

  testimonialCard.addEventListener('touchend', function(e) {
    if (!startX || !startY) return;

    const endX = e.changedTouches[0].clientX;
    const endY = e.changedTouches[0].clientY;

    const diffX = startX - endX;
    const diffY = startY - endY;

    if (Math.abs(diffX) > Math.abs(diffY)) {
      if (Math.abs(diffX) > 50) {
        nextTestimonial();
      }
    }

    startX = 0;
    startY = 0;
  });
}

document.addEventListener('DOMContentLoaded', addSwipeSupport);

</script>
<!-- <script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script> -->
<?php include("footer.php"); ?>