  <!-- Get In Touch Section -->
        <section class="get-in-touch-section">
            <div class="get-in-touch-content">
                <div class="brochure-cards">
                    <div class="brochure-card">
                        <h3 class="brochure-title">Pitch Deck</h3>
                        <a href="#" class="brochure-link">
                            <img src="assets/icons/pdf.svg" alt="PDF" class="brochure-icon" />
                            <span class="brochure-text">pdf</span>
                        </a>
                    </div>
                    <div class="brochure-card dark">
                        <h3 class="brochure-title">Corporate Identity</h3>
                        <a href="#" class="brochure-cta">View Materials</a>
                    </div>
                </div>
                <div class="contact-info-section">
                    <h2 class="contact-info-title">Get In Touch</h2>
                    <div class="contact-locations">
                        <div class="location">
                            <h3 class="location-title">Ahmedabad</h3>
                            <div class="location-item">
                                <img src="assets/icons/location.svg" alt="Address" class="location-icon" />
                                <span class="location-text">203, Harsh Avenue, Navrangpura, Ahmedabad, Gujarat 380009</span>
                            </div>
                            <div class="location-item">
                                <img src="assets/icons/phone.svg" alt="Phone" class="location-icon" />
                                <span class="location-text"><a href="tel:+916357173693">+91 6357173693</a></span>
                            </div>
                            <div class="location-item">
                                <img src="assets/icons/email.svg" alt="Email" class="location-icon" />
                                <span class="location-text"><a href="mailto:business@imacengineering.com">business@imacengineering.com</a></span>
                            </div>
                        </div>
                        <div class="location">
                            <h3 class="location-title">United States</h3>
                            <div class="location-item">
                                <img src="assets/icons/location.svg" alt="Address" class="location-icon" />
                                <span class="location-text">21512 Lake Forest Dr, Lake Forest, California 92630, United States</span>
                            </div>
                        </div>
                        <div class="location">
                            <h3 class="location-title">United Kingdom</h3>
                            <div class="location-item">
                                <img src="assets/icons/location.svg" alt="Address" class="location-icon" />
                                <span class="location-text">6 Sutton Rd, Harrow HA2 6ET, London, United Kingdom</span>
                            </div>
                            <div class="location-item">
                                <img src="assets/icons/phone.svg" alt="Phone" class="location-icon" />
                                <span class="location-text"><a href="+44 7810427007">+44 7810 427007</a></span>
                            </div>
                        </div>
                        <div class="location">
                            <h3 class="location-title">Pune</h3>
                            <div class="location-item">
                                <img src="assets/icons/location.svg" alt="Address" class="location-icon" />
                                <span class="location-text">H 706, Sukhwani Skylines, Wakad, Pune, 411057</span>
                            </div>
                        </div>
                        <div class="location">
                            <h3 class="location-title">Canada</h3>
                            <div class="location-item">
                                <img src="assets/icons/location.svg" alt="Address" class="location-icon" />
                                <span class="location-text">140 Cherryhill Pl, 809, London, Ontario N6H 4M5, Canada</span>
                            </div>
                            <div class="location-item">
                                <img src="assets/icons/phone.svg" alt="Phone" class="location-icon" />
                                <span class="location-text"><a href="tel:5483883470">5483883470</a>, <a href="tel:5485670037">5485670037</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer class="footer">
            <a href="index.php"><img src="assets/image/logo.svg" alt="iMAC Logo" class="footer-logo" /></a>
            <div class="footer-content">
                <a href="#" class="footer-link">Privacy Policy</a>
                <span class="footer-text">© 2025 iMAC Design & Engineering Services. All Rights Reserved</span>
                
            </div>
        </footer>
    </div>
<script src="js/script.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/tabs.js"></script>
<script src="js/navigation.js"></script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>


    </body>
</html>