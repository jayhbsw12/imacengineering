<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Reverse Engineering Services Provider</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Reverse Engineering Services Provider</h1>
         <p class="banner-description">
            Using high-accuracy 3D scanning, iMAC Design and Engineering Services captures every shape, edge, and surface detail of a component, process, or system. The data is converted into CAD models for exact replication, redesign, or performance upgrades. With 100+ projects delivered, 
            we support industries like automotive, aerospace, medical, oil & gas, and heavy engineering.
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get your Quote Now</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">Your Expert Partner<br />in Reverse Engineering Services</h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>Reverse engineering is the process of dismantling a part or a component to understand its design, function, and materials, so it can be recreated, improved, or modernized. This service is widely used where original designs are lost, competitor benchmarking is needed, obsolete components require reproduction, or product improvement is necessary.</p>
         <p>At iMAC Design and Engineering Services, we combine 3D scanning with powerful CAD tools to extract exact geometry, internal features, and manufacturing data. With 5 years of proven results and 30+ global clients, we have built a process that is fast, reliable, and precise. </p>
         <p>From capturing the smallest shape variation to ensuring material strength, our team of experts only delivers dependable outcomes. Among 3D scanning reverse engineering companies, we are the partner that delivers clarity, consistency, and better product outcomes.</p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Mechanical CAD Drafting Services</h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">2D/3D Component Drafting</h3>
            <div class="service-divider"></div>
            <p class="service-description">We offer comprehensive 2D/3D component drafting services, enabling engineers and designers to create detailed and accurate representations of parts and assemblies. Our precise drafting techniques facilitate efficient manufacturing and ensure perfect design, reducing errors and accelerating project timelines.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Legacy CAD Conversion</h3>
            <div class="service-divider"></div>
            <p class="service-description">Our legacy CAD conversion services transform 2D files into accurate 3D models, optimizing your design workflow. Engineers and manufacturers benefit from our high-precision conversion, ensuring that old designs integrate smoothly into production systems without compromising on quality or functionality.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Manufacturing Drawings & Tolerances</h3>
            <div class="service-divider"></div>
            <p class="service-description">We deliver accurate manufacturing drawings with precise tolerances that meet the specific production requirements. Our drawings deliver exact detail & information to ensure parts are produced within specifications, enhancing quality control and minimizing production errors. </p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Reverse Engineering & Scanning</h3>
            <div class="service-divider"></div>
            <p class="service-description">Through our advanced reverse engineering and 3D scanning services, we help engineers and product designers capture and recreate complex geometries. Whether for component restoration or design refinement, we provide models, enabling accurate reproduction and optimization of existing parts or assemblies.</p>
         </article>
      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">Benefits of<br class="m-hidden"> Reverse Engineering Services </h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">You can rebuild the discontinued components even without technical drawings, using accurate 3D scans and CAD reconstruction expertise from the team of iMAC design & engineering experts. </p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">With our reverse engineering services, you can get the functionality, durability, or efficiency by analyzing current designs and applying engineering-focused performance improvements.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">Reverse engineering will help you convert the hand-crafted molds or aging parts into digital models for easier documentation, storage, and future reproduction.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">Our team of experts will generate precise part documentation and geometry to support government approvals, quality standards, or compliance certifications.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">With reverse engineering, it becomes easy to get nominal CAD models to inspect manufactured parts, detect deviations, and improve overall production accuracy.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">It becomes easy to capture the exact shapes through scanning to design accurate, cost-effective molds for manufacturing or prototyping purposes using our reverse engineering services. </p>
            </div>
         </div>
        
        <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">It gets easy to get the insights into competitor designs by studying layout, function, and features through our expert reverse engineering services.</p>
            </div>
            <!-- <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">It becomes easy to capture the exact shapes through scanning to design accurate, cost-effective molds for manufacturing or prototyping purposes using our reverse engineering services. </p>
            </div> -->
         </div>

      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">Why Choose iMAC Design and Engineering<br class="m-hidden"> for Reverse  Engineering Services?</h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>Specialized Engineering <br class="m-hidden">Expertise</h3>
            </div>
            <div class="feature-back">
               <p>Our skilled engineers bring decades of experience in 3D scanning, CAD modeling, and PCB reverse engineering, using advanced metrology tools for an excellent sub-micron accuracy.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Complete Project <br class="m-hidden">Ownership</h3>
            </div>
            <div class="feature-back">
               <p>From disassembly and 3D scanning to CAD modeling and prototyping, the entire process is handled in-house for better control, quality, and communication throughout the process.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3>Quick Project <br class="m-hidden">Execution</h3>
            </div>
            <div class="feature-back">
               <p>We offer rapid prototyping and structured workflows that reduce lead times, allowing faster iterations, design improvements, and quicker transitions from scan to working prototype.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Cost-Efficient Solutions</h3>
            </div>
            <div class="feature-back">
               <p>Our process minimizes unnecessary R&D trials by enhancing existing designs, helping clients save significantly on tooling, redesign efforts, and future manufacturing expenses.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Legacy Component Restoration</h3>
            </div>
            <div class="feature-back">
               <p>We recreate obsolete parts without original drawings - ideal for industries like aerospace, automotive, and heavy machinery that depend on legacy system compatibility and restoration.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Competitive Product Analysis</h3>
            </div>
            <div class="feature-back">
               <p>You can gain strategic insights from competitor products using ethical, data-driven reverse engineering methods to improve your own design, functionality, and market positioning.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>IP Protection Focus</h3>
            </div>
            <div class="feature-back">
               <p>We ensure complete compliance with intellectual property regulations, giving you peace of mind throughout every phase of your reverse engineering project.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Customization and<br class="m-hidden"> Enhancement</h3>
            </div>
            <div class="feature-back">
               <p>We ensure complete compliance with intellectual property regulations, giving you peace of mind throughout every phase of your reverse engineering project.</p>
            </div>
         </div>

      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process">Our Proven Reverse Engineering Process </h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">Product/system pre-screening</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>At this phase, we carefully examine the product or system for reverse engineering. It involves studying its components, functions, and overall structure.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Research</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This crucial stage involves gathering as much information as possible about the analyzed product or system.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Disassembly</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This step involves breaking down the product or system into components to understand how they function together.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Information Extraction</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This step consists of collecting data from the disassembled components.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Modeling</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>In this phase, we use specialized software tools like CAD to create virtual models that depict the original design.</p>
                  </div>
               </div>

                <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">06.</span>
                     <h3 class="step-title">Review</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This crucial step involves carefully examining all the gathered information, ensuring nothing has been overlooked or misunderstood. </p>
                  </div>
               </div>

               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">07.</span>
                     <h3 class="step-title">Documentation</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This step involves creating detailed reports, diagrams, and documentation that capture the findings and insights gained.</p>
                  </div>
               </div>

                <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">08.</span>
                     <h3 class="step-title">Product development</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>During this stage, engineers can identify any areas of improvement in the original design and make necessary modifications.</p>
                  </div>
               </div>

            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">What is reverse engineering, and how does it work?</span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Reverse engineering is the process of deconstructing a product or system to understand its design, structure, or to extract knowledge from the product or system. It works by analyzing a product's physical structure, components, and functionalities to create a blueprint or detailed understanding of its original design without having access to the initial design specifications. This can involve 3D scanning, material analysis, and functional testing to recreate models or documentation.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Why would I need reverse engineering services?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p><b>You might need reverse engineering services for various reasons, including:</b></p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Replicating obsolete or discontinued parts : To reproduce components no longer manufactured. </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i>Improving existing designs: To analyze competitors' products or enhance your own. </p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Interoperability and integration: To ensure new products work smoothly with existing systems. </p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Product failure analysis:  To investigate product failures or intellectual property infringement. </p>
                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Lost documentation:  To recreate design information when the original blueprints are unavailable. </p>


            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Is reverse engineering legal and ethical?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>The legality and ethics of reverse engineering depend heavily on the jurisdiction and specific circumstances. 
                In many countries, reverse engineering is generally legal if conducted for purposes such as interoperability, research, 
                or to fix defects, provided it doesn't infringe on intellectual property rights like patents or copyrights. 
                However, it becomes illegal when used to directly copy patented designs or copyrighted software for commercial gain, 
                or if it violates non-disclosure agreements. Ethical considerations revolve around respecting intellectual property 
                and competitive fairness.</p>
            </div>
         </div>
        
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Can reverse engineering be used for obsolete or discontinued parts?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Yes, reverse engineering is a highly effective and common solution for obsolete or 
                discontinued parts. When original manufacturers no longer produce a component, reverse 
                engineering allows for the creation of new manufacturing data and processes. This enables the 
                reproduction of critical parts, ensuring the continued operation and maintenance of legacy systems, machinery, 
                or products, thereby extending their lifespan and avoiding costly replacements of entire assemblies.</p>
            </div>
         </div>

      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>