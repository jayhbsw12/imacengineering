<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Additive Manufacturing Service</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Rapid and Reliable Additive Manufacturing Service Provider</h1>
         <p class="banner-description">
          At iMAC Design and Engineering Services, we bring your designs to life with the finest in additive manufacturing.
           Using top-grade materials like ABS and PLA, and technologies like FDM, SLA, SLS, and DMLS, we deliver accurate, functional 
           prototypes. We have delivered 100+ successful parts across industries, proving the power of doing things right, layer by layer.
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get your Quote Now</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">Fast and Smart Additive <br class="m-hidden"> Manufacturing Services</h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>At iMAC Design and Engineering Services, we offer reliable, high-precision additive manufacturing services and 3D 
            prototype printing services for industries like aerospace, automotive, and healthcare. Our certified team of engineers, 
            designers, and technicians uses advanced technologies such as FDM, SLA, SLS, and DMLS to build complex parts with less waste and
             greater efficiency. </p>
         <p>We work with trusted materials like ABS, PLA, white ABS resin, and transparent clear ABS to create durable, 
            accurate components for real-world use. With our metal additive manufacturing expertise, we can repair worn parts, 
            add protective coatings, and even create hybrid structures. </p>
         <p>Following global standards like ISO and ASTM, we ensure every part meets the highest benchmarks. 
            Looking ahead, we are excited to expand into new industries and explore the next wave of innovation in additive manufacturing.</p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Our Additive Manufacturing Solutions</h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Alpha/Beta Validation AM Model (FDM/SLA)</h3>
            <div class="service-divider"></div>
            <p class="service-description">We build alpha and beta prototypes using advanced FDM and SLA technologies, 
                allowing early-stage validation with high precision. We design models using updated software and expert techniques; 
                these models help clients test form, fit, and functionality before moving into full production.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Miniature Exhibition Model</h3>
            <div class="service-divider"></div>
            <p class="service-description">We design compact, high-detail miniature models for exhibitions using the latest additive 
                manufacturing tools. We create the same with updated design software and crafted by skilled technicians, these models 
                offer an engaging way to present complex concepts at expos, meetings, or pitches.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Scaled Working Model</h3>
            <div class="service-divider"></div>
            <p class="service-description">We deliver fully functional scaled models built through advanced additive manufacturing. 
                These working models simulate real-world mechanisms, created with precision using updated design tools. Ideal for demos 
                and training, they combine movement, accuracy, and durability with easy accessibility and customisation.</p>
         </article>
         <!-- <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Tooling & Manufacturing</h3>
            <div class="service-divider"></div>
            <p class="service-description">From prototype to production, our team of experts ensures your 
                product is ready to scale. We optimize designs for manufacturing, reduce costs, and ensure consistency 
                so you can move from one unit to thousands without compromising quality or performance.</p>
         </article> -->
      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">What are the Benefits of  <br class="m-hidden">3D Prototype Printing Services?</h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">We speed up your product journey. With our rapid prototyping, we cut development time, 
                allowing quicker testing, feedback, and faster entry into the competitive market.</p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">We help you save on development costs. Our 3D printing services eliminate expensive tooling, 
                offering affordable, accurate prototypes without compromising quality or stretching your project budget.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">We bring your creative ideas to life. Our services adapt to complex shapes and frequent
                 design updates, without slowing down the speed of innovation.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">We provide working prototypes you can test. Our models reflect real-world performance,
                 helping you validate design, fit, and function before moving into large-scale production quickly & confidently.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">We build smartly and sustainably. Our additive process uses only what is needed, minimizing 
                material waste while producing durable, high-quality parts for practical, responsible prototyping. </p>
            </div>
            <!-- <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">With proven processes and in-house capabilities, we reduce design revisions, compress timelines, 
                and support quicker time-to-market, without compromising quality, compliance, or long-term product performance.</p>
            </div> -->
         </div>
      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">Why You Can Trust  <br class="m-hidden"> Our 3D Printing Services? </h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>Proven Track Record</h3>
            </div>
            <div class="feature-back">
               <p>With 100+ successful projects and 30+ global clients, we have consistently delivered high-quality, 
                functional prototypes that solve real problems and exceed expectations every time.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Certified Quality Standards</h3>
            </div>
            <div class="feature-back">
               <p>Our 3D printing services are globally recognized and approved under ISO and ASTM standards, 
                ensuring every part we produce is accurate, consistent, and performs reliably.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3>Advanced Technology & Materials</h3>
            </div>
            <div class="feature-back">
               <p>We use the latest 3D printing technologies, such as FDM, SLA, SLS, DMLS, 
                and high-grade materials like ABS and PLA to produce parts built for real-world use.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Skilled Team and Personal Approach</h3>
            </div>
            <div class="feature-back">
               <p>Our skilled team collaborates with you directly, combining hands-on experience with a problem-solving mindset to
                 deliver exactly what your design or product requires.</p>
            </div>
         </div>

        <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Innovation That Makes a Difference</h3>
            </div>
            <div class="feature-back">
               <p>From part repair to hybrid builds, we apply advanced techniques that reduce waste, improve performance, 
                and create smarter outcomes for your business.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process">Our Medical Product Design & Development Process</h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">Initial Analysis and Planning</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The first phase involves assessing the market, competition, and regulatory requirements, 
                        ensuring a clear understanding of legal and financial agendas.</p>

                    <p>Design inputs are collected while considering risk assessment and potential challenges. 
                        This stage builds a strong foundation for the project, focusing on compliance, strategic analysis, 
                        and financial feasibility to support the next steps of development. Detailed planning at this stage 
                        minimizes potential issues down the line.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Concept and Feasibility</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>During this phase, the concept of the device is created, incorporating initial design input. 
                        Prototypes are developed and evaluated to determine feasibility and performance in real-world scenarios. 
                        Pre-clinical trials and evaluation refine the design further. </p>
                        <p>This phase involves creating a tangible version of the idea and assessing its practicality. 
                            Iterative prototyping enables efficient testing and validation of the concept.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Design and Development</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This phase integrates key design input to create a comprehensive set of design specifications,
                         leading to the development of the product.</p>
                    <p>Through detailed design output, the product’s feasibility and performance are verified. 
                        Design failure modes are considered, and risk management is actively incorporated. Design 
                        validation tests and the Device History File (DHF) are documented thoroughly.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Manufacturing and Validation</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>With design specifications and outputs finalized, the device enters manufacturing, 
                        either in pilot runs or full-scale production. Design validation ensures that the 
                        product performs as intended in the real world as well.</p>

                    <p>A comprehensive process validation includes testing, quality assurance, and compliance checks.
                         Clinical research projects may be conducted to ensure safety and efficacy in real-world applications. 
                         This stage brings the device closer to market.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Post-Launch Monitoring</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Once the product is launched, ongoing training, audits, and updates are essential to 
                        ensure continued compliance and optimal performance.</p>
                        <p>Post-market surveillance gathers data from actual users, helping refine future iterations.
                             This phase ensures that potential issues are addressed promptly while monitoring long-term 
                             device performance. Customer feedback plays a pivotal role, enabling proactive adjustments to the design, 
                             manufacturing, and overall user experience to maintain the device’s effectiveness. </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">What is additive manufacturing, and how does it benefit product development?</span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Additive manufacturing, commonly known as 3D printing, is a process of creating three-dimensional 
                objects layer by layer from a digital design. It benefits product development by enabling rapid prototyping, 
                complex geometries, lightweight designs, and on-demand production. This accelerates design iterations, reduces 
                tooling costs, allows for customization, and can lead to more efficient product performance due to design freedom.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Is 3D printing suitable for production or just prototyping?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>3D printing is suitable for both prototyping and production, though its application varies. While it works best at
                 rapid prototyping to validate designs and functions, advancements in materials and technology have made it increasingly 
                 viable for low-volume production, custom parts, and even mass customization. Industries like aerospace, medical, and 
                 automotive are now using 3D printing for end-use components, proving its capability beyond just prototyping.</p> 
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Can you print functional prototypes or just visual models?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Yes, we can print highly functional prototypes in addition to visual models. Our capabilities include using 
                a range of high-quality engineering materials that possess properties such as strength, flexibility, heat resistance,
                 and chemical resistance. This allows us to create prototypes that accurately replicate the mechanical performance 
                 and environmental behavior of the final product, enabling thorough testing and validation.</p>
            </div>
         </div>

        <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What is the cost structure for your 3D printing services?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>For detailed information on the cost structure for our 3D printing services, please contact us. 
                    Our pricing is dependent on factors such as part complexity, material selection, print volume,
                     required post-processing, and urgency. We provide customized quotes after reviewing your specific project requirements.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">How do you ensure quality and consistency in 3D printed parts?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p><b>We ensure quality and consistency in 3D printed parts through a varied approach:</b></p>
                 <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Strict Process Control </p>
                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Material Verification </p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Advanced Equipment </p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Post-Processing Expertise </p>
                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Quality Inspection </p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Experienced Technicians</p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>