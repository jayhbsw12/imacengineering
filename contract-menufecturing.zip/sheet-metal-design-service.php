<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Sheet Metal Design Development and Manufacturing</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Sheet Metal Design Development and Manufacturing Company</h1>
         <p class="banner-description">
        iMAC Design and Engineering specializes in custom sheet metal design solutions perfect for kiosks, enclosures, and industrial
         applications. Working with mild steel, aluminum, and stainless steel. Our fabrication expertise covers 0.8mm to 25mm thickness
          in mild steel, stainless steel, and aluminum. Need it fast? We deliver custom prototypes in just 7 days! 
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get a quote</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">Our Sheet Metal Designs  <br class="m-hidden"> that Outperform the Competition</h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>We offer complete sheet metal fabrication services from laser cutting to finishing. 
            iMAC Design and Engineering has delivered over 100 quality enclosures and kiosks that meet exact specifications.</p>
         <p>We maintain tight tolerances across all projects, ensuring your parts fit perfectly every time. 
            Our quality control process catches variations before they become problems. Our engineers calculate
             precise bend allowances and K-factors for each material and thickness. This means your flat patterns
              unfold exactly as designed, without any problem.</p>
         <p>Choose from powder coating, anodizing, plating, or brushed finishes. Each option protects your parts while giving 
            them the look you want. We handle deburring, chamfering, and edge rolling to eliminate sharp edges and create smooth,
             safe surfaces.</p>
        <p>As a trusted sheet metal manufacturing company, we handle the technical details so you get parts that work right the first time.</p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Sheet Metal Design and Development Services</h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Laser Cutting</h3>
            <div class="service-divider"></div>
            <p class="service-description">We offer high-precision laser cutting for complex designs and tight tolerances. 
                Our CNC laser machines handle various metals, delivering clean, burr-free edges perfect for prototypes and 
                production. Fast, accurate, and ideal for complex geometries. Bring your detailed designs to life with perfect cuts.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Plasma Cutting</h3>
            <div class="service-divider"></div>
            <p class="service-description">Our industrial plasma cutting delivers powerful metal cutting for thick materials.
                 This works perfectly for large-scale projects or one-off fabrications; it maintains quality on steel, aluminum,
                  and more. You can easily expect clean cuts and quick turnaround, without any compromise on strength or precision. </p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Metal Bending</h3>
            <div class="service-divider"></div>
            <p class="service-description">Precision bending can change the flat metal into functional parts with consistent
                 angles and smooth finishes. Our press brakes handle everything from delicate folds to heavy-duty bends in steel, 
                 stainless steel, and aluminum. Accurate, repeatable, and designed according to your specifications(every time).</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Waterjet Cutting</h3>
            <div class="service-divider"></div>
            <p class="service-description">High-pressure waterjet cutting performs through thick metals without heat distortion, 
                preserving material integrity. This is ideal for heat-sensitive or tough materials; it delivers smooth edges 
                and complex shapes. No hardening, you can expect just clean cuts for any project, big or small.</p>
         </article>

         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting"> Metal Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">From welding to riveting, our assembly services easily convert 
                fabricated parts into finished products. We ensure sturdy, smooth joins that meet structural
                 and aesthetic demands. Simplify your production with our reliable techniques, reducing your
                  workload while maintaining top-tier quality and durability.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Metal Enclosures</h3>
            <div class="service-divider"></div>
            <p class="service-description">Custom metal enclosures protect your electronics, machinery, or components
                 with a perfect fit. Durable, cost-effective. Our enclosures are designed and developed keeping in mind 
                 the industrial standards while working on their functionality. From design to delivery, we design and develop 
                 solutions that last.</p>
         </article>
         <!-- <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Test What Works</h3>
            <div class="service-divider"></div>
            <p class="service-description">Your 3D miniature model builds working prototypes that move, fit, and function exactly
                 like the real thing, preventing expensive surprises during manufacturing.</p>
         </article> -->
      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">What are the Benefits of <br class="m-hidden">Our Sheet Metal Fabrication Services? </h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">Our team of experts delivers strong and durable parts that perform exceptionally well in heavy-duty
                 applications without breaking down over time in demanding environments.</p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">Our proven process shapes complex geometries while maintaining structural
                 integrity throughout the entire forming process, ensuring all the parts and process matches 
                 your exact design specifications.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">We offer cost-effective solutions compared to casting, forging, 
                or machining for both prototypes and production process, saving you money on your projects.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text"> You can choose from our wide material range that includes mild steel, aluminum, stainless steel, 
                brass, copper, and titanium options, giving you flexibility for any application requirements.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">We maintain consistent wall thickness across the entire parts, eliminating weak points and 
                ensuring uniform strength throughout your fabricated components for reliability.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">Our fast turnaround converts your 3D design files to finished parts using automated cutting and 
                forming technology, delivering quality results on schedule.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">Why Choose  iMAC Design & Engineering’s <br class="m-hidden"> Sheet Metal Fabrication Services? </h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>100+ Projects Delivered</h3>
            </div>
            <div class="feature-back">
               <p>We have successfully delivered over 100 quality enclosures and kiosks across multiple(heavy) 
                industries with consistent results that exceed client expectations every time.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Material Expertise</h3>
            </div>
            <div class="feature-back">
               <p>Our experienced team handles mild steel, stainless steel, and aluminum from 0.8mm to 25mm thickness
                 with precision and technical expertise for projects.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3> Design Innovation</h3>
            </div>
            <div class="feature-back">
               <p>We combine technical expertise with creative design solutions for kiosks, PCB enclosures, 
                and custom fabrication as according to your specific application requirements perfectly.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Cost Effective</h3>
            </div>
            <div class="feature-back">
               <p>Our sheet metal fabrication offers lower costs compared to casting, forging, 
                or machining for your projects while maintaining superior quality and performance.</p>
            </div>
         </div>

        <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Quality Assurance</h3>
            </div>
            <div class="feature-back">
               <p>We maintain strict tolerances and design parameters, ensuring parts meet your exact specifications 
                every time with consistent quality and reliable manufacturing processes.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process">The Process Of Creating <br class="m-hidden">a 3D Miniature Model</h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">Project Initiation</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The first step of the process begins with reviews and approval of the quotation, then we proceed by
                         issuing the Purchase Order (PO) to the client, and after that client releases advance payment to
                          initiate the project.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Design Finalization</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>At step two of our process, we review and modify the 3D model, only if it's needed. 
                        After modifications, we share the final 3D model with the client for approval.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Pre-Execution Planning </h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Then we proceed with the confirmation of painting details, colors, finishes, or any sticker/branding 
                        requirements. After that, we begin the preparation of the Bill of Materials (BOM) execution sheet, 
                        incorporating all design and finish specifications; without BOM sheet approval, execution or procurement
                         is not possible. </p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Model Fabrication </h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>At the fourth stage there is the execution of the miniature model-making 
                        process using approved 3D files and BOM.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Finishing & Quality Control </h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>After execution, we begin with the assembly and post-processing (sanding, painting, decals, etc).</p>
                  </div>
               </div>

                <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">06.</span>
                     <h3 class="step-title">Quality control checks</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The next stage is to send the model for pre-dispatch review to the client for approval.
                         We provide both of the methods for reviews ( online and offline)</p>
                  </div>
               </div>

               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">07.</span>
                     <h3 class="step-title">Final Delivery & Project Closure</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The last stage comes with the final dispatch of the completed model. We then collect the feedback
                         and make changes if any. Then comes the closure of the PO upon final approval and delivery, and the 
                         remaining payment gets cleared at this stage.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">What is rapid tooling? </span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Rapid tooling is a method of quickly creating molds, dies, or other manufacturing tools, primarily 
                for prototyping or low-volume production. It leverages additive manufacturing (3D printing) and 
                high-speed machining to produce tooling much faster and often more affordably than conventional methods.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">How does rapid tooling differ from traditional tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Rapid tooling differs from traditional tooling primarily in its speed, cost, and typical volume suitability. 
                Traditional tooling involves lengthy, expensive processes like EDM of hard metals for high-volume, durable molds.
                 Rapid tooling utilizes faster, often additive methods and less durable materials, ideal for quick iterations, 
                 prototypes, or low to medium production runs.</p> 
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What materials can be used in rapid tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p> Rapid tooling can use a variety of materials, including polymers (plastics), composites, and even some metals. 
                Common materials include photopolymers, ABS, nylon, and various resins for 3D printed molds, as well as softer 
                aluminum alloys or high-density epoxies for machined tools.</p>
            </div>
         </div>

        <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What types of molds are used in rapid tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Rapid tooling employs various mold types, including injection molds, vacuum forming molds, blow molds, 
                    and soft tooling inserts. These molds can be 3D printed directly (e.g., plastic molds for silicone 
                    casting or short-run injection molding) or produced by rapidly machining softer metals or tooling boards.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Is rapid tooling suitable for low-volume production?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Yes, rapid tooling is highly suitable for low-volume production. Its speed and lower cost per tool make it an 
                    excellent choice for producing hundreds or thousands of parts before committing to expensive, high-volume 
                    traditional tooling, or for bridge production between prototyping and mass manufacturing.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>