<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Medical Device Design & Development</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Innovative Medical Device Design & Development Experts</h1>
         <p class="banner-description">
            We specialize in designing and manufacturing Class I and Class II medical devices for healthcare companies, 
            OEMs, and startups. Our team leads in design innovation, offering customized solutions from concept through production. 
            We ensure compliance with CDSCO, ISO 13485, ISO/TR 20416, and ISO 20417 standards, providing strong testing of biocompatibility,
             usability, and sterilization to deliver reliable, safe, and regulatory-compliant products.
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get your Quote Now</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">Medical Device Product Design <br />and Development for Healthcare Success</h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>At iMAC Design & Engineering Services, a leading medical device design and development company, we use a special Maniac-Elegant approach to create devices that have a strong emotional bond between users and systems. 
</p>
         <p>We provide end-to-end medical device product design and development, including MVP prototyping, contract manufacturing, and integration services. With over 5 years of experience, we have delivered successful devices like Patient Warmer Devices, Wound management Devices, Smart Reminders Devices, Blood Bank Products, and ICU multiparameter monitors. Our expert team combines industrial and electronic design with human-centered research, ensuring designs are ergonomically optimized and FDA compliant. In addition, we focus on building UI/UX to work better along with software development.
</p>
         <p>We focus on practical, user-friendly designs that meet ISO 13485 and regulatory standards, guaranteeing high-quality products from concept to manufacturing, making us a trusted medical device design and engineering service provider.
</p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Mechanical CAD Drafting Services</h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">2D/3D Component Drafting</h3>
            <div class="service-divider"></div>
            <p class="service-description">We offer comprehensive 2D/3D component drafting services, enabling engineers and designers to create detailed and accurate representations of parts and assemblies. Our precise drafting techniques facilitate efficient manufacturing and ensure perfect design, reducing errors and accelerating project timelines.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Legacy CAD Conversion</h3>
            <div class="service-divider"></div>
            <p class="service-description">Our legacy CAD conversion services transform 2D files into accurate 3D models, optimizing your design workflow. Engineers and manufacturers benefit from our high-precision conversion, ensuring that old designs integrate smoothly into production systems without compromising on quality or functionality.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Manufacturing Drawings & Tolerances</h3>
            <div class="service-divider"></div>
            <p class="service-description">We deliver accurate manufacturing drawings with precise tolerances that meet the specific production requirements. Our drawings deliver exact detail & information to ensure parts are produced within specifications, enhancing quality control and minimizing production errors. </p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Reverse Engineering & Scanning</h3>
            <div class="service-divider"></div>
            <p class="service-description">Through our advanced reverse engineering and 3D scanning services, we help engineers and product designers capture and recreate complex geometries. Whether for component restoration or design refinement, we provide models, enabling accurate reproduction and optimization of existing parts or assemblies.</p>
         </article>
      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">Benefits of Medical Product <br class="m-hidden"> Design & Development Services</h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">At iMAC Design & Engineering Services, we ensure your product complies with industry standards 
                like CDSCO, FDA, ISO 13485, and CE, minimizing risks and ensuring safety and effectiveness.</p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">Our expert team ensures a smooth product development process, accelerating your medical device's 
                time-to-market and enabling you to deliver innovative healthcare solutions efficiently and effectively.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">We focus on human-centered design, ensuring our devices are intuitive and easy to use,
                 ultimately improving patient outcomes and promoting greater adoption in the healthcare industry.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">By optimizing the design for manufacturing, we reduce material waste 
                and improve production efficiency, lowering your overall product costs without sacrificing quality and consistency. </p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">Through our prototyping and testing services, we help identify design flaws early, 
                ensuring your device is functional, usable, and meets regulatory and biocompatibility standards before mass production.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">Our expertise in advanced electronic design allows us to create medical devices with precision,
                 functionality, and connectivity, providing smarter solutions for healthcare professionals.</p>
               </div>
         </div>

        <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">Through our prototyping and testing services, we help identify design flaws early, 
                ensuring your device is functional, usable, and meets regulatory and biocompatibility standards before mass production.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">Our designs are scalable, allowing for easy updates and integration of 
                new technologies, ensuring your product remains relevant and adaptable as the healthcare industry changes.</p>
               </div>
         </div>

         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">We focus on durability and reliability, ensuring your device withstands wear and tear, 
                providing long-term performance and longevity in demanding healthcare environments.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">Our team combines engineering expertise with creative innovation, 
                enabling us to develop medical devices that not only meet clinical needs but also introduce excellent 
                solutions to healthcare challenges.</p>
               </div>
         </div>

      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">Why iMAC Design and Engineering? </h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>Advanced Device Innovation</h3>
            </div>
            <div class="feature-back">
               <p>We sketch the brilliant designs that are highly reliable, user-friendly medical equipment, 
                including IUDs, ECG recorders, X-ray machines, and other sophisticated devices made for medical/healthcare professionals.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Human-Centered Design</h3>
            </div>
            <div class="feature-back">
               <p>Our design engineers focus on human-centered principles, improving medical device usability while 
                ensuring adaptive modifications through reverse engineering for improved functionality in the healthcare field.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3>Emotional User Connection</h3>
            </div>
            <div class="feature-back">
               <p>Using our Maniac-Elegant approach, we create medical devices that facilitate emotional 
                bonds between users, doctors, and patients, elevating user experience and satisfaction for better care.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Precision Engineering Expertise</h3>
            </div>
            <div class="feature-back">
               <p>With extensive experience, our team utilizes CAD-based tools to identify and solve complex problems early, 
                ensuring smooth compliance and certification for safe, reliable medical devices.</p>
            </div>
         </div>

        <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Customization and Security</h3>
            </div>
            <div class="feature-back">
               <p>We prioritize IP protection, securing designs, and ensuring customized solutions for the 
                medical device sector while maintaining high standards of quality and safety in all developments.</p>
            </div>
         </div>

      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process">Our Medical Product Design & Development Process</h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">Initial Analysis and Planning</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The first phase involves assessing the market, competition, and regulatory requirements, 
                        ensuring a clear understanding of legal and financial agendas.</p>

                    <p>Design inputs are collected while considering risk assessment and potential challenges. 
                        This stage builds a strong foundation for the project, focusing on compliance, strategic analysis, 
                        and financial feasibility to support the next steps of development. Detailed planning at this stage 
                        minimizes potential issues down the line.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Concept and Feasibility</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>During this phase, the concept of the device is created, incorporating initial design input. 
                        Prototypes are developed and evaluated to determine feasibility and performance in real-world scenarios. 
                        Pre-clinical trials and evaluation refine the design further. </p>
                        <p>This phase involves creating a tangible version of the idea and assessing its practicality. 
                            Iterative prototyping enables efficient testing and validation of the concept.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Design and Development</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This phase integrates key design input to create a comprehensive set of design specifications,
                         leading to the development of the product.</p>
                    <p>Through detailed design output, the product’s feasibility and performance are verified. 
                        Design failure modes are considered, and risk management is actively incorporated. Design 
                        validation tests and the Device History File (DHF) are documented thoroughly.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Manufacturing and Validation</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>With design specifications and outputs finalized, the device enters manufacturing, 
                        either in pilot runs or full-scale production. Design validation ensures that the 
                        product performs as intended in the real world as well.</p>

                    <p>A comprehensive process validation includes testing, quality assurance, and compliance checks.
                         Clinical research projects may be conducted to ensure safety and efficacy in real-world applications. 
                         This stage brings the device closer to market.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Post-Launch Monitoring</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Once the product is launched, ongoing training, audits, and updates are essential to 
                        ensure continued compliance and optimal performance.</p>
                        <p>Post-market surveillance gathers data from actual users, helping refine future iterations.
                             This phase ensures that potential issues are addressed promptly while monitoring long-term 
                             device performance. Customer feedback plays a pivotal role, enabling proactive adjustments to the design, 
                             manufacturing, and overall user experience to maintain the device’s effectiveness. </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">What is medical device design and development?</span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Medical device design and development is a highly regulated, multidisciplinary process of conceptualizing, 
                designing, prototyping, testing, and validating devices intended for medical purposes. It encompasses everything 
                from initial ideation and feasibility studies to regulatory submission, manufacturing specifications, and post-market 
                surveillance, ensuring the device is safe, effective, and compliant with global health authority standards.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What types of medical devices do you specialize in designing?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p><b>We specialize in designing a broad range of medical devices, with particular expertise in areas such as:</b></p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> IntraUterine devices </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i>Biopsy CT scan assistive devices </p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Ultrasonic piezoelectric dental scaler </p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i>  X-ray machine </p>
                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> ECG recorder design </p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Cardiac stress test treadmill design</p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> ICU multiparameter monitor</p>

               <p>Our focus is on devices that prioritize user-centric design, clinical efficacy, and regulatory compliance 
                across their lifecycle.</p>

                
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Can you help with both the design and the manufacturing process of medical devices?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Yes, we provide comprehensive support that extends beyond just design to include the critical manufacturing process 
                for medical devices. Our services encompass design for manufacturability (DFM) considerations during the initial stages, 
                selecting appropriate manufacturing partners, overseeing production, and establishing quality control protocols.
                 This integrated approach ensures a smooth transition from concept to mass production, maintaining device 
                 integrity and regulatory compliance throughout.</p>
            </div>
         </div>

        <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">How do you handle intellectual property and patent protection for medical device designs?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p><b>We handle intellectual property (IP) and patent protection for medical device designs with confidentiality.
                     Our process typically includes :</b></p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> We sign NDAs for the confidentiality of your proprietary information. </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> We ensure that all your developed IP is assigned to the client.</p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> We provide advice on patentability and assist with preliminary patent searches. </p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> We document all design iterations and innovations to support patent applications. </p>
                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> We utilize secure systems for all project data and communications. </p>

               <p>Our goal is to safeguard your innovations and ensure strong legal protection for your medical device designs.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What is the difference between Class I, Class II, and Class III medical devices?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p><b>Medical devices are categorized into classes based on their potential risks to patients and users, dictating the level of regulatory control required.
</b></p>
               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i>Class I devices present the lowest risk (e.g., bandages, stethoscopes) and are subject to general controls. </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Class II devices pose a moderate risk (e.g., infusion pumps, surgical drapes) 
               and require general controls plus special controls like performance standards.</p>

                <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i>Class III devices carry the highest risk (e.g., pacemakers, heart valves) and necessitate the most 
               stringent controls, including premarket approval (PMA) due to their life-supporting, or implantable nature, 
               or their potential for unreasonable risk of illness or injury.</p>
            </div>
         </div>


      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>