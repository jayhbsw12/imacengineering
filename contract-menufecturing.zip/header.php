<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>iMAC Design & Engineering Services</title>
      <meta name="robots" content="noindex,nofollow">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/header.css">
      <link rel="stylesheet" href="css/reset.css">
      <link rel="stylesheet" href="css/variables.css">
      <link rel="stylesheet" href="css/layout.css">
      <link rel="stylesheet" href="css/slider.css">
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/counter.css">
      <link rel="stylesheet" href="css/responsive.css">
      <!-- <link rel="stylesheet" href="css/variables-industry.css">
      <link rel="stylesheet" href="css/layout-industry.css"> -->
      <link rel="stylesheet" href="css/industries.css">
      <!-- <link rel="stylesheet" href="css/responsive-industry.css"> -->
      <link rel="stylesheet" href="css/insights.css">
      <link rel="stylesheet" href="css/logo-slider.css">
      <link rel="stylesheet" href="css/portfolio.css">
      <link rel="stylesheet" href="css/testimonial.css">
      <link rel="stylesheet" href="css/service-hero.css">
      <link rel="stylesheet" href="css/banner-logos.css">
      <link rel="stylesheet" href="css/service-responsive.css">
      <link rel="stylesheet" href="css/cad-outsourcing-service.css">
      <link rel="shortcut icon" href="assets/icons/fevicon.svg">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
   </head>
   <body>
      <div id="mainHeader">
         <header class="main-header">
            <!-- Top Header -->
            <div class="top-header">
               <div class="logo">
                  <a href="index.php"><img src="assets/image/logo.svg" alt="IMAC Logo" /></a>
               </div>
               <!-- Mobile Toggle -->
               <button class="mobile-toggle" id="mobileToggle">
               <i class="fa-solid fa-bars"></i>
               </button>
               <div class="mobile-nav" id="mobileNav">
                  <ul>
                     <li><a href="#" class="active">Home</a></li>
                     <li><a href="#">About us</a></li>
                     <!-- Services with Dropdown -->
                     <li class="has-submenu">
                        <a href="#">Services <i class="fa-solid fa-chevron-down submenu-toggle"></i></a>
                        <ul class="submenu">
                           <li><a href="https://designmasters.in/imac/cad-outsourcing-service.php">CAD Outsourcing Services</a></li>
                           <li><a href="https://designmasters.in/imac/contract-menufecturing.php">Contract Manufacturing</a></li>
                           <li><a href="https://designmasters.in/imac/additive-manufacturing-service.php">Additive Manufacturing</a></li>
                           <li><a href="">Innovation & IP Strategy</a></li>
                           <li><a href="https://designmasters.in/imac/integration-services.php">Integration Services</a></li>
                           <li><a href="#">3D Miniature Design</a></li>
                           <li><a href="https://designmasters.in/imac/reverse-engineering-service.php">Reverse Engineering Services</a></li>
                           <li><a href="https://designmasters.in/imac/rapid-tooling-services.php">Tooling Design and Manufacturing</a></li>
                           <li><a href="#">MVP Prototyping</a></li>
                           <li><a href="https://designmasters.in/imac/medical-device-design-development.php">Medical Product Design</a></li>
                            <li><a href="https://designmasters.in/imac/sheet-metal-design-service.php">Sheet Metal Design</a></li>
                        </ul>
                     </li>
                     <li><a href="#">Portfolio</a></li>
                     <li><a href="#">Industry</a></li>
                     <!-- Resources with Dropdown -->
                     <li class="has-submenu">
                        <a href="#">Resources <i class="fa-solid fa-chevron-down submenu-toggle"></i></a>
                        <ul class="submenu">
                           <li><a href="#">Blogs</a></li>
                           <li><a href="#">Case Studies</a></li>
                        </ul>
                     </li>
                     <li><a href="#">Get in Touch</a></li>
                  </ul>
                  <!-- Optional CTA Button -->
                  <!--
                     <div class="mobile-nav-btn">
                       <a href="#" class="btn-orange">Schedule an Appointment <i class="fa-solid fa-arrow-right"></i></a>
                     </div>
                     -->
               </div>
               <div class="contact-group">
                  <div class="contact-item">
                     <i class="fa-solid fa-phone-volume"></i>
                     <div class="text">
                        <small>Call Us 24/7</small>
                        <a href="tel:+91 6357173693"><strong>+91 6357173693</strong></a>
                     </div>
                  </div>
                  <div class="divider"></div>
                  <div class="contact-item">
                     <i class="fa-regular fa-envelope"></i>
                     <div class="text">
                        <small>Send Us Mail</small>
                        <a href="mailto:business@imacengineering.com"><strong>business@imacengineering.com</strong></a>
                     </div>
                  </div>
               </div>
            </div>
      </div>
      <!-- Mobile Navigation -->
      <!-- Navigation Row -->
      <div class="nav-row">
      <!-- Desktop Nav -->
      <nav class="main-nav">
      <ul>
      <li><a href="#" class="active">Home</a></li>
      <li><a href="#">About us</a></li>
      <li class="has-mega-menu">
      <a href="#">Services <span class="arrow">&#9662;</span></a>
      <div class="mega-menu">
      <div class="mega-menu-left">
      <div>
      <h3>Lorem ipsum dolor sit amet</h3>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
      </div>
      <a href="#" class="get-started">Get Started</a>
      </div>
      <div class="mega-menu-right">
      <ul class="menu-list">
      <li><a href="cad-outsourcing-services.php"><img src="assets/icons/mega-menu/cad-outsourcing-services.svg" alt=""> <span>CAD Outsourcing Services</span></a></li>
      <li><a href="product-design-development.php"><img src="assets/icons/mega-menu/product-design-development.svg" alt=""> <span>Product Design and Development</span></a></li>
      <li><a href="contract-manufacturing.php"><img src="assets/icons/mega-menu/contract-menufacturing.svg" alt=""> <span>Contract Manufacturing</span></a></li>
      <li><a href="reverse-engineering-services.php"><img src="assets/icons/mega-menu/Reverse-Engineering-Services.svg" alt=""> <span>Reverse Engineering Services</span></a></li>
      <li><a href="additive-manufacturing.php"><img src="assets/icons/mega-menu/Additive-Manufacturing.svg" alt=""> <span>Additive Manufacturing</span></a></li>
      <li><a href="tooling-design-manufacturing.php"><img src="assets/icons/mega-menu/Tooling-Design-and-Manufacturing-Services.svg" alt=""> <span>Tooling Design and Manufacturing</span></a></li>
      <li><a href="innovation-ip-strategy.php"><img src="assets/icons/mega-menu/Innovation-&-IP-Strategy.svg" alt=""> <span>Innovation & IP Strategy</span></a></li>
      <li><a href="mvp-prototyping.php"><img src="assets/icons/mega-menu/MVP-Prototyping-&-Manufacturing-as-Services.svg" alt=""> <span>MVP Prototyping</span></a></li>
      <li><a href="integration-services.php"><img src="assets/icons/mega-menu/Integration-Services.svg" alt=""> <span>Integration Services</span></a></li>
      <li><a href="medical-product-design.php"><img src="assets/icons/mega-menu/Medical-Product-Design-&-Development.svg" alt=""> <span>Medical Product Design</span></a></li>
      <li><a href="3d-printed-models.php"><img src="assets/icons/mega-menu/3D-Printed-Miniature-Exhibition-Model.svg" alt=""> <span>3D Miniature Design</span></a></li>
      <li><a href="sheet-metal-design.php"><img src="assets/icons/mega-menu/Sheet-Metal-Design-Services.svg" alt=""> <span>Sheet Metal Design</span></a></li>
      </ul>
      </div>
      </div>
      </li>
      <li><a href="#">Portfolio</a></li>
      <li><a href="#">Industry</a></li>
     <li class="has-mega-menu">
      <a href="#">Resources<span class="arrow">&#9662;</span></a>
      <div class="mega-menu small-megamenu">
      <div class="mega-menu-right small">
      <ul class="menu-list">
      <li><a href="#"><span>Blogs</span></a></li>
      <li><a href="#"><span>Case Study</span></a></li>
      </ul>
      </div>
      </div>
      </li>
      <li><a href="#">Get in Touch</a></li>
      </ul>
      </nav>
      <!-- Desktop Button -->
      <a href="#" class="btn-orange">
      Schedule an Appointment <i class="fa-solid fa-arrow-right"></i>
      </a>
      </header>
      </div>
      <header class="header sticky-header">
         <div class="header-container">
            <!-- Logo Section -->
            <div class="logo-section">
               <button class="mobile-menu-toggle" aria-label="Toggle mobile menu">
               <img src="https://static.codia.ai/custom_image/2025-07-05/073118/menu-icon.svg" alt="Menu" class="menu-icon">
               </button>
               <div class="logo-group">
                  <div class="logo-icons">
                     <a href="index.php"> <img src="https://static.codia.ai/custom_image/2025-07-05/073118/small-icon.svg" alt="" class="small-icon"></a>
                     <a href="index.php"><img src="https://static.codia.ai/custom_image/2025-07-05/073118/logo-icon.svg" alt="" class="logo-icon"></a>
                  </div>
                  <div class="logo-text">
                     <a href="index.php"><img src="https://static.codia.ai/custom_image/2025-07-05/073118/logo-text.svg" alt="Company Logo" class="logo-text-img"></a>
                     <a href="index.php"><img src="https://static.codia.ai/custom_image/2025-07-05/073118/logo-underline.svg" alt="" class="logo-underline"></a>
                  </div>
               </div>
            </div>
            <!-- Navigation -->
            <nav class="navigation">
               <ul class="nav-list">
                  <li class="nav-item">
                     <a href="#" class="nav-link active">Home</a>
                  </li>
                  <li class="nav-item">
                     <a href="#" class="nav-link">About us</a>
                  </li>
                  <li class="nav-item has-mega-menu dropdown">
                     <a href="#" class="nav-link">Services</a>
                     <img src="https://static.codia.ai/custom_image/2025-07-05/073118/dropdown-icon-1.svg" alt="" class="dropdown-icon">
                     <div class="mega-menu">
                        <div class="mega-menu-left">
                           <div>
                              <h3>Lorem ipsum dolor sit amet</h3>
                              <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                           </div>
                           <a href="#" class="get-started">Get Started</a>
                        </div>
                        <div class="mega-menu-right">
                           <ul class="menu-list">
                              <li>
                                 <a href="cad-outsourcing-services.php">
                                 <img src="assets/icons/mega-menu/cad-outsourcing-services.svg" alt=""> <span> CAD Outsourcing Services </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="product-design-development.php">
                                 <img src="assets/icons/mega-menu/product-design-development.svg" alt=""><span> Product Design and Development </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="contract-manufacturing.php">
                                 <img src="assets/icons/mega-menu/contract-menufacturing.svg" alt=""> <span> Contract Manufacturing </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="reverse-engineering-services.php">
                                 <img src="assets/icons/mega-menu/Reverse-Engineering-Services.svg" alt=""> <span> Reverse Engineering Services </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="additive-manufacturing.php">
                                 <img src="assets/icons/mega-menu/Additive-Manufacturing.svg" alt=""> <span> Additive Manufacturing </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="tooling-design-manufacturing.php">
                                 <img src="assets/icons/mega-menu/Tooling-Design-and-Manufacturing-Services.svg" alt=""> <span> Tooling Design and Manufacturing </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="innovation-ip-strategy.php">
                                 <img src="assets/icons/mega-menu/Innovation-&-IP-Strategy.svg" alt=""> <span> Innovation & IP Strategy </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="mvp-prototyping.php">
                                 <img src="assets/icons/mega-menu/MVP-Prototyping-&-Manufacturing-as-Services.svg" alt=""> <span> MVP Prototyping </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="integration-services.php">
                                 <img src="assets/icons/mega-menu/Integration-Services.svg" alt=""> <span> Integration Services </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="medical-product-design.php">
                                 <img src="assets/icons/mega-menu/Medical-Product-Design-&-Development.svg" alt=""> <span> Medical Product Design </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="3d-printed-models.php">
                                 <img src="assets/icons/mega-menu/3D-Printed-Miniature-Exhibition-Model.svg" alt=""> <span> 3D Miniature Design </span>
                                 </a>
                              </li>
                              <li>
                                 <a href="sheet-metal-design.php">
                                 <img src="assets/icons/mega-menu/Sheet-Metal-Design-Services.svg" alt=""> <span> Sheet Metal Design </span>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item">
                     <a href="#" class="nav-link">Portfolio</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a href="#" class="nav-link">Industry</a>
                  </li>
                  <li class="nav-item has-mega-menu dropdown">
                     <a href="#" class="nav-link">Resources</a>
                     <img src="https://static.codia.ai/custom_image/2025-07-05/073118/dropdown-icon-1.svg" alt="" class="dropdown-icon">
                     <div class="mega-menu small-megamenu">
                        <div class="mega-menu-right small">
                           <ul class="menu-list">
                              <li>
                                 <a href="cad-outsourcing-services.php">
                                  <span>Blogs</span>
                                 </a>
                              </li>
                              <li>
                                 <a href="product-design-development.php">
                                 <span> Case Studies </span>
                                 </a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item">
                     <a href="#" class="nav-link">Get in Touch</a>
                  </li>
               </ul>
            </nav>
            <!-- CTA Section -->
            <div class="cta-section">
               <div class="appointment-btn">
                  <a href="#" class="appointment-link">Schedule an Appointment</a>
                  <img src="https://static.codia.ai/custom_image/2025-07-05/073118/dropdown-arrow.svg" alt="" class="appointment-arrow">
               </div>
            </div>
         </div>
         <!-- Mobile Navigation -->
         <nav class="mobile-navigation">
            <ul class="mobile-nav-list">
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link active">Home</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">About us</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">Services</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">Our Portfolio</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">Portfolio</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">Resources</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">Industry Verticles</a>
               </li>
               <li class="mobile-nav-item">
                  <a href="#" class="mobile-nav-link">Get in Touch</a>
               </li>
            </ul>
         </nav>
      </header>
      <script>
         document.addEventListener("DOMContentLoaded", function () {
         const menuToggle = document.getElementById("mobileToggle");
         const mobileNav = document.getElementById("mobileNav");
         
         // Toggle main mobile menu
         menuToggle.addEventListener("click", function () {
         mobileNav.classList.toggle("active");
         });
         
         // Close mobile nav on link click (optional)
         mobileNav.querySelectorAll("a").forEach(link => {
         link.addEventListener("click", function () {
         // Only close if the clicked link is NOT a submenu toggle
         if (!this.closest(".has-submenu")) {
          mobileNav.classList.remove("active");
         }
         });
         });
         
         // Toggle submenus
         const submenuToggles = document.querySelectorAll(".has-submenu > a");
         
         submenuToggles.forEach(toggle => {
         toggle.addEventListener("click", function (e) {
         e.preventDefault(); // Prevent default anchor
         const parentLi = this.parentElement;
         
         // Close other open submenus (optional)
         document.querySelectorAll(".has-submenu").forEach(li => {
          if (li !== parentLi) li.classList.remove("active");
         });
         
         parentLi.classList.toggle("active");
         });
         });
         });
      </script>