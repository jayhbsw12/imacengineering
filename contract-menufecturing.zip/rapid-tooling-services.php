<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Rapid Tooling And Manufacturing Services</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Rapid Tooling And Manufacturing Services Company</h1>
         <p class="banner-description">
          Get high-quality rapid tooling solutions in less than 2 weeks(without compromising on accuracy),
           cutting traditional lead times by 70%. Our 15+ successfully deployed rapid tools have helped
            engineering industries eliminate production delays while maintaining excellent quality.
             Our expert team specializes in rapid tooling using high-grade aluminum, steel, and advanced plastic materials.
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get your Quote Now</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">Rapid Tooling Design <br class="m-hidden"> And Manufacturing</h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>Time and cost shouldn't stand between your design and the market. That's where our rapid tooling 
            expertise makes the difference. We combine CNC machining (for both metals and plastics) with advanced techniques 
            like FDM, SLA, SLS, DLP-LPSC, vacuum casting, and 3D printing to create high-quality tooling solutions in couple 
            of weeks rather than months.</p>
         <p>With over 10,000 hours of hands-on expertise in tool design services and tooling manufacturing services, 
            we have developed methods for producing molds, jigs, and prototypes according to strict industry standards.
             Our low-cost rapid tooling development approach helps businesses reduce the expenses of prototyping, shorten 
             the timelines of production, and maintain consistent standards of quality. </p>
         <p>From initial concept to final production, we provide the speed and quality that modern manufacturing demands,
             where time and budget matter most.</p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Our Rapid Tooling Design And Manufacturing Services</h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Fusion Deposition <br class="m-hidden"> Modeling (FDM)</h3>
            <div class="service-divider"></div>
            <p class="service-description">This technique is perfect for durable plastic prototypes and functional parts. 
                FDM builds layer by layer using thermoplastic materials, creating strong, cost-effective tools ideal for 
                testing and low-volume production runs with excellent dimensional accuracy.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Stereolithography (SLA)</h3>
            <div class="service-divider"></div>
            <p class="service-description">This method by us is designed to deliver ultra-precise parts with smooth 
                surface finishes. Using liquid resin cured by UV light, SLA creates details and complex geometries 
                perfect for high-resolution prototypes and detailed tooling applications.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Selective Laser <br class="m-hidden">Sintering (SLS)</h3>
            <div class="service-divider"></div>
            <p class="service-description">SLS builds strong, complex parts without supports by laser-fusing powder materials. 
                This works perfectly for functional prototypes and end-use parts; it offers design freedom, durability, 
                and heat resistance. This technique is ideal for rapid tooling solutions.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Digital Light <br class="m-hidden"> Processing (DLP-LPSC)</h3>
            <div class="service-divider"></div>
            <p class="service-description">This technique is fast, accurate printing for detailed components.
                 DLP cures entire layers at the same time. It uses digital light projection, delivering quick 
                 turnaround times for parts with brilliant surface quality and fine features.</p>
         </article>

         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Vacuum Casting (VC)</h3>
            <div class="service-divider"></div>
            <p class="service-description">This service is designed to produce multiple copies from master patterns. 
                VC creates high-quality polyurethane parts in silicone molds, perfect for low-volume production runs,
                 functional testing, and bridge manufacturing before full-scale production.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">3D Printing</h3>
            <div class="service-divider"></div>
            <p class="service-description">Speed up innovation with our multi-material, multi-technology rapid prototyping solutions. 
                From concept models to functional prototypes, our complete 3D printing services cut development costs and accelerate
                 design iterations, bringing your ideas to market faster.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">CNC Machining</h3>
            <div class="service-divider"></div>
            <p class="service-description">You can expect precision manufacturing for metals and plastics with this technique.
                 Our advanced CNC capabilities deliver tight tolerances and superior surface finishes, creating production-ready 
                 tools and components that meet exact specifications and quality standards.</p>
         </article>
      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">What are the Benefits of Rapid Tooling  <br class="m-hidden">Design & Engineering Services? </h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">Our tooling design services make sure to use tight tolerances (ISO 2768) and 
                optimized geometries using CAD/CAM & FEA, reducing defects and improving part consistency for superior
                 manufacturing performance.</p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">Utilizing rapid prototyping (ASTM F42) and CNC machining, we accelerate mold development,
                 cutting down the lead times by 70% getting your product to market quicker.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">Advanced DFM (Design for Manufacturing) principles minimize material waste and machining time, 
                cutting tooling costs by 20-40% without compromising durability or performance.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text"> We use hardened tool steels (H13, P20,) and conformal cooling (SAE AMS 4999) to extend mold life,
                 sustaining 300,000+ cycles with minimal wear.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">From prototyping (ISO 9001) to mass production, our tooling adapts smoothly, 
                supporting low-to-high volume needs while maintaining dimensional accuracy (ASME Y14.5).</p>
            </div>
            <!-- <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">With proven processes and in-house capabilities, we reduce design revisions, compress timelines, 
                and support quicker time-to-market, without compromising quality, compliance, or long-term product performance.</p>
            </div> -->
         </div>
      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">The Reasons Why You Should Choose <br class="m-hidden"> Our Tooling Manufacturing Services  </h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>Fast Delivery Times</h3>
            </div>
            <div class="feature-back">
               <p>We deliver rapid tools in under 2 weeks, eliminating production delays and keeping your manufacturing schedules
                 on track with our quick, efficient tooling design & engineering services. </p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Latest Technology Adaptability</h3>
            </div>
            <div class="feature-back">
               <p>From FDM to CNC machining, we offer complete tooling solutions at one place and by one
                 single expert team, saving you time and the costs of coordinating multiple vendors.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3>Heavy Industry Expertise</h3>
            </div>
            <div class="feature-back">
               <p>With 10,000+ hours serving demanding engineering sectors, we understand complex requirements and 
                deliver tools that fight strict industrial applications and environments.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Cost-Effective Solutions</h3>
            </div>
            <div class="feature-back">
               <p>Our low-cost rapid tooling development reduces your investment by up to 60% compared 
                to traditional methods while maintaining exceptional quality standards.</p>
            </div>
         </div>

        <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Proven Track Record</h3>
            </div>
            <div class="feature-back">
               <p>With five successful rapid tools delivered( many more to come) a with zero quality issues, backed by 
                dedicated engineering support and comprehensive post-delivery assistance for complete peace.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process">The Process Of Low-Cost <br class="m-hidden">Rapid Tooling Development</h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">The Basics</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The process involves two primary methods: direct and indirect tooling.
                         Direct tooling builds molds from digital designs, while indirect tooling creates a master pattern to form the mold.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Design Analysis</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>We review your specifications, evaluate design complexity, and recommend the best and 
                        effective manufacturing methods to ensure cost-effective rapid tooling solutions.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Material Selection</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>At this second stage, our experts choose appropriate materials based on your application requirements,
                         balancing performance, durability, and budget for maximum value.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Technology Matching</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>At the third stage of the process, we select the best rapid tooling technology -
                         FDM, SLA, SLS, DLP, or CNC machining that perfectly matches your project needs.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Digital Prototyping</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The fourth stage has advanced CAD modeling and simulation that validate your design before
                         manufacturing, preventing costly revisions and ensuring optimal tool performance.</p>
                  </div>
               </div>

                <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">06.</span>
                     <h3 class="step-title">Rapid Manufacturing</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The next step of the process is where the tool is produced using our advanced equipment and skilled 
                        craftsmanship, maintaining strict quality control throughout the entire process.</p>
                  </div>
               </div>

               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">07.</span>
                     <h3 class="step-title">Quality Testing</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Lastly then we conduct a comprehensive inspection and testing to verify dimensional accuracy, surface finish, 
                        and functionality before delivery to guarantee your complete satisfaction.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">What is rapid tooling? </span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Rapid tooling is a method of quickly creating molds, dies, or other manufacturing tools, primarily 
                for prototyping or low-volume production. It leverages additive manufacturing (3D printing) and 
                high-speed machining to produce tooling much faster and often more affordably than conventional methods.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">How does rapid tooling differ from traditional tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Rapid tooling differs from traditional tooling primarily in its speed, cost, and typical volume suitability. 
                Traditional tooling involves lengthy, expensive processes like EDM of hard metals for high-volume, durable molds.
                 Rapid tooling utilizes faster, often additive methods and less durable materials, ideal for quick iterations, 
                 prototypes, or low to medium production runs.</p> 
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What materials can be used in rapid tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p> Rapid tooling can use a variety of materials, including polymers (plastics), composites, and even some metals. 
                Common materials include photopolymers, ABS, nylon, and various resins for 3D printed molds, as well as softer 
                aluminum alloys or high-density epoxies for machined tools.</p>
            </div>
         </div>

        <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What types of molds are used in rapid tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Rapid tooling employs various mold types, including injection molds, vacuum forming molds, blow molds, 
                    and soft tooling inserts. These molds can be 3D printed directly (e.g., plastic molds for silicone 
                    casting or short-run injection molding) or produced by rapidly machining softer metals or tooling boards.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Is rapid tooling suitable for low-volume production?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Yes, rapid tooling is highly suitable for low-volume production. Its speed and lower cost per tool make it an 
                    excellent choice for producing hundreds or thousands of parts before committing to expensive, high-volume 
                    traditional tooling, or for bridge production between prototyping and mass manufacturing.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>