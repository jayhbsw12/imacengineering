// Main JavaScript functionality
document.addEventListener('DOMContentLoaded', function() {
  // Initialize the application
  initializeApp();
});

function initializeApp() {
  // Initialize button interactions
  initializeButtons();
  
  // Initialize scroll animations
  initializeScrollAnimations();
  
  // Initialize responsive behavior
  initializeResponsiveBehavior();
}

function initializeButtons() {
  const ctaButton = document.querySelector('.cta-button');
  
  if (ctaButton) {
    ctaButton.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Add click animation
      this.style.transform = 'translateY(2px)';
      setTimeout(() => {
        this.style.transform = '';
      }, 150);
      
      // Scroll to stats section
      const statsSection = document.querySelector('.stats-section');
      if (statsSection) {
        statsSection.scrollIntoView({ 
          behavior: 'smooth',
          block: 'start'
        });
      }
      
      console.log('Discover More button clicked');
    });
  }
}

function initializeScrollAnimations() {
  // Create intersection observer for animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in');
      }
    });
  }, observerOptions);
  
  // Observe stat cards
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
    observer.observe(card);
  });
  
  // Add CSS for animation
  const style = document.createElement('style');
  style.textContent = `
    .animate-in {
      opacity: 1 !important;
      transform: translateY(0) !important;
    }
  `;
  document.head.appendChild(style);
}

function initializeResponsiveBehavior() {
  let resizeTimer;
  
  window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
      handleResize();
    }, 250);
  });
  
  // Initial call
  handleResize();
}

function handleResize() {
  const windowWidth = window.innerWidth;
  
  // Adjust layout based on screen size
  if (windowWidth <= 480) {
    adjustMobileLayout();
  } else if (windowWidth <= 768) {
    adjustTabletLayout();
  } else {
    adjustDesktopLayout();
  }
}

function adjustMobileLayout() {
  // Mobile-specific adjustments
  const heroContent = document.querySelector('.hero-content');
  if (heroContent) {
    heroContent.style.minHeight = 'auto';
  }
}

function adjustTabletLayout() {
  // Tablet-specific adjustments
  const heroContent = document.querySelector('.hero-content');
  if (heroContent) {
    heroContent.style.minHeight = 'auto';
  }
}

function adjustDesktopLayout() {
  // Desktop-specific adjustments
  const heroContent = document.querySelector('.hero-content');
  if (heroContent) {
    heroContent.style.minHeight = '519px';
  }
}

// Utility function for smooth scrolling
function smoothScrollTo(element, duration = 1000) {
  const targetPosition = element.offsetTop;
  const startPosition = window.pageYOffset;
  const distance = targetPosition - startPosition;
  let startTime = null;
  
  function animation(currentTime) {
    if (startTime === null) startTime = currentTime;
    const timeElapsed = currentTime - startTime;
    const run = ease(timeElapsed, startPosition, distance, duration);
    window.scrollTo(0, run);
    if (timeElapsed < duration) requestAnimationFrame(animation);
  }
  
  function ease(t, b, c, d) {
    t /= d / 2;
    if (t < 1) return c / 2 * t * t + b;
    t--;
    return -c / 2 * (t * (t - 2) - 1) + b;
  }
  
  requestAnimationFrame(animation);
}

// Performance optimization
function debounce(func, wait, immediate) {
  let timeout;
  return function executedFunction() {
    const context = this;
    const args = arguments;
    const later = function() {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

// Export functions for potential module use
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    initializeApp,
    smoothScrollTo,
    debounce
  };
}
