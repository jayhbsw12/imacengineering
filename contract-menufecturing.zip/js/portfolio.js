document.addEventListener('DOMContentLoaded', function () {
  const filters = document.querySelectorAll('.filter');
  const items = document.querySelectorAll('.portfolio-item');

  // Filter logic
  filters.forEach(filter => {
    filter.addEventListener('click', () => {
      filters.forEach(f => f.classList.remove('active'));
      filter.classList.add('active');
      const value = filter.getAttribute('data-filter');
      items.forEach(item => {
        if (value === 'all' || item.classList.contains(value)) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });

  // Lightbox logic
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-image');
  const lightboxClose = document.querySelector('.lightbox-close');

  document.querySelectorAll('.zoom-button').forEach(button => {
    button.addEventListener('click', function (e) {
      e.stopPropagation(); // Prevent triggering unwanted events
      const imageSrc = button.getAttribute('data-image');
      lightboxImg.src = imageSrc;
      lightbox.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  });

  lightboxClose.addEventListener('click', () => {
    lightbox.classList.remove('active');
    document.body.style.overflow = 'auto';
  });

  lightbox.addEventListener('click', e => {
    if (e.target === lightbox) {
      lightbox.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  });
});

