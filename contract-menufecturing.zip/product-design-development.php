<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Product Design and Development Company</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Product Design and Development Company</h1>
         <p class="banner-description">
           iMAC Design and Engineering Services delivers advanced product design and development services across challenging industries. 
           From initial sketch to final prototype, we combine creativity with engineering expertise. Trusted by global brands, 
           we have brought bold ideas to life, solving technical challenges, accelerating time-to-market, and redefining innovation across 
           sectors like medical devices, oil & gas, and next-generation smart products.
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get your Quote Now</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">High-Quality Product Design <br class="m-hidden"> and Development Services</h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>At iMAC Design and Engineering, we help companies bring new ideas to life with practical design.</p>
         <p>As a trusted product design studio and new product development company, we start with sketches, build working prototypes,
             and support the entire journey through manufacturing. From medical devices, smart gadgets, wearables, laboratory equipment,
              and consumer products etc., we create solutions that are built for real use.</p>
         <p>Our team brings together creative thinking and solid engineering to tackle tough challenges across multiple sectors. 
            We design with people in mind and refine every detail until the product feels right. With 30+ global clients and 100+
             successful projects, we have delivered products that perform and stand out. You will find some of our most recognised 
             product designs in our portfolio for many brands, business types, and industries. </p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Our Product Design Engineering Services</h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Industrial Design</h3>
            <div class="service-divider"></div>
            <p class="service-description">Using our new product development services, we create the face of your product, 
                defining user experience, form, and function. Our industrial designs balance aesthetics with real-world usability 
                that connects with users while aligning with engineering and manufacturing requirements.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting">Product Engineering & Prototyping</h3>
            <div class="service-divider"></div>
            <p class="service-description">Our team of engineers at iMAC Design and Engineering Services builds fully functional 
                prototypes that validate every detail, such as mechanical, electrical, and user-focused. We ensure your product 
                not only looks good but also performs reliably before moving into full-scale production.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Embedded System Development</h3>
            <div class="service-divider"></div>
            <p class="service-description">Our product design and development services add intelligence to your product. 
                Our embedded systems integrate hardware and software to power smart features, connectivity, and data flow, 
                converting standalone devices into smart, interactive, and future-ready innovations across industries.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Tooling & Manufacturing</h3>
            <div class="service-divider"></div>
            <p class="service-description">From prototype to production, our team of experts ensures your 
                product is ready to scale. We optimize designs for manufacturing, reduce costs, and ensure consistency 
                so you can move from one unit to thousands without compromising quality or performance.</p>
         </article>
      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">Benefits of Product Design <br class="m-hidden">and Development Services</h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">You get end-to-end support - from concept development and CAD modelling to prototyping and DFM, 
                ensuring faster execution, reduced costs, and smooth collaboration through every product development phase.</p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">You get everything in one place, industrial design, engineering, prototyping, and 
                manufacturing managed and executed by a one experienced team that understands your product inside out. </p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">Your intellectual property is safe with us. We operate under strict NDAs, maintain secure data protocols,
                 and ensure full confidentiality from design research through engineering handoff and production tooling.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">We bring clarity to complex ideas. Through feasibility studies, design research,
                 and technical exploration, we help refine your product vision into a functional, user-aligned, and manufacturable solution.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">Our iterative approach involves rapid prototyping, usability testing, and user validation, 
                ensuring your product aligns with market needs, performs reliably, and delivers real value before final production.</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">With proven processes and in-house capabilities, we reduce design revisions, compress timelines, 
                and support quicker time-to-market, without compromising quality, compliance, or long-term product performance.</p>
               </div>
         </div>
      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">Why Choose Our Product <br class="m-hidden"> Design Engineering Services? </h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>End-to-End Support</h3>
            </div>
            <div class="feature-back">
               <p>We manage everything from concept development to production launch, covering design, prototyping, engineering, 
                and DFM with one experienced team working with your product’s complete lifecycle.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Multidisciplinary Expertise</h3>
            </div>
            <div class="feature-back">
               <p>Our design engineers focus on human-centered principles, improving medical device usability while 
                ensuring adaptive modifications through reverse engineering for improved functionality in the healthcare field.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3>Manufacturing Ready</h3>
            </div>
            <div class="feature-back">
               <p>We prepare engineering outputs like BOMs, CTF drawings, and tolerance stack-ups to ensure manufacturability, 
                cost-efficiency, and minimal design revisions during mass production.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Cost-Effective Design</h3>
            </div>
            <div class="feature-back">
               <p>We develop working prototypes to explore design alternatives, verify technical feasibility, and identify potential
                 failures, ensuring confident decision-making before moving into production tooling.</p>
            </div>
         </div>

        <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Startup Friendly</h3>
            </div>
            <div class="feature-back">
               <p>We partner with startups to engineer complex concepts - providing hands-on guidance, technical expertise, 
                and flexible workflows that turn innovative ideas into achievable, launch-ready products.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Regulatory Compliance</h3>
            </div>
            <div class="feature-back">
               <p>We work with strict industry and government standards, solving regulatory challenges early to
                 ensure your product meets every compliance requirement.</p>
            </div>
         </div>

          <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Smart Material Use</h3>
            </div>
            <div class="feature-back">
               <p>Our knowledge in material science allows us to choose the right materials, balancing performance, cost, 
                and reliability for a competitive market edge.</p>
            </div>
         </div>

          <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Engineering Analysis</h3>
            </div>
            <div class="feature-back">
               <p>We perform CAE analysis and DFMEA to assess durability, fatigue, and life expectancy, ensuring your product performs
                 well under practical conditions.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>User-Centric Design</h3>
            </div>
            <div class="feature-back">
               <p>We extract emotional insights from user personas and apply them to create products that connect with the right 
                audience on a deeper level.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Modern Methods</h3>
            </div>
            <div class="feature-back">
               <p>We integrate traditional engineering with emerging technologies like 3D printing, IoT, 
                and hybrid cloud - accelerating innovation without compromising reliability.</p>
            </div>
         </div>

         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Prototyping Focus</h3>
            </div>
            <div class="feature-back">
               <p>Our prototypes go beyond models; they’re functional tools for testing usability, durability, 
                and design flaws before finalising your product for production.</p>
            </div>
         </div>

      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process">Our Medical Product Design & Development Process</h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">Initial Analysis and Planning</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>The first phase involves assessing the market, competition, and regulatory requirements, 
                        ensuring a clear understanding of legal and financial agendas.</p>

                    <p>Design inputs are collected while considering risk assessment and potential challenges. 
                        This stage builds a strong foundation for the project, focusing on compliance, strategic analysis, 
                        and financial feasibility to support the next steps of development. Detailed planning at this stage 
                        minimizes potential issues down the line.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Concept and Feasibility</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>During this phase, the concept of the device is created, incorporating initial design input. 
                        Prototypes are developed and evaluated to determine feasibility and performance in real-world scenarios. 
                        Pre-clinical trials and evaluation refine the design further. </p>
                        <p>This phase involves creating a tangible version of the idea and assessing its practicality. 
                            Iterative prototyping enables efficient testing and validation of the concept.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Design and Development</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>This phase integrates key design input to create a comprehensive set of design specifications,
                         leading to the development of the product.</p>
                    <p>Through detailed design output, the product’s feasibility and performance are verified. 
                        Design failure modes are considered, and risk management is actively incorporated. Design 
                        validation tests and the Device History File (DHF) are documented thoroughly.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Manufacturing and Validation</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>With design specifications and outputs finalized, the device enters manufacturing, 
                        either in pilot runs or full-scale production. Design validation ensures that the 
                        product performs as intended in the real world as well.</p>

                    <p>A comprehensive process validation includes testing, quality assurance, and compliance checks.
                         Clinical research projects may be conducted to ensure safety and efficacy in real-world applications. 
                         This stage brings the device closer to market.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Post-Launch Monitoring</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Once the product is launched, ongoing training, audits, and updates are essential to 
                        ensure continued compliance and optimal performance.</p>
                        <p>Post-market surveillance gathers data from actual users, helping refine future iterations.
                             This phase ensures that potential issues are addressed promptly while monitoring long-term 
                             device performance. Customer feedback plays a pivotal role, enabling proactive adjustments to the design, 
                             manufacturing, and overall user experience to maintain the device’s effectiveness. </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">Do you offer end-to-end product development or just specific stages?</span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>We offer end-to-end product development services, guiding your concept from initial ideation through 
                to manufacturing support. While we are equipped to manage the entire lifecycle, we can also engage at specific 
                stages based on your needs, such as concept generation, prototyping, engineering design, or design for manufacturing. 
                Our flexible approach ensures you receive support precisely where it's required.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What industries do you specialize in for product design?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>We specialize in product design across a diverse range of industries, including oil & gas, heavy industry, 
                medical devices, security & surveillance, laboratory equipment, smart devices/IoTs, consumer industry, FMCG, 
                agriTech, dairy tech, and clean tech</p> 
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Can you assist with manufacturing once the product is ready?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Yes, we can assist with manufacturing once the product design is finalized. Our services extend to Design 
                for Manufacturability (DFM) optimization, identifying suitable manufacturing partners, supplier vetting, and overseeing 
                the initial production runs. While we typically don't directly own manufacturing facilities, we utilize our network and 
                expertise to facilitate a smooth transition from design to scalable production.</p>
            </div>
         </div>

        <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What is the cost structure for your product design and development services?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>For detailed information on the cost structure for our product design and development services,
                     please contact us. Our pricing is customized based on the project's scope, complexity, required expertise, 
                     and anticipated duration. We offer transparent proposals after understanding your specific needs.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Can you work with existing products to improve or redesign them?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Yes, we work with existing products to improve, refine, or completely redesign them. Whether you're looking to enhance
                     functionality, improve user experience, reduce manufacturing costs, update aesthetics, or adapt to new technologies,
                      our team can analyze your current product, identify areas for optimization, and implement innovative solutions to 
                      achieve your goals.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Will I own the final product design, and how do I protect it?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Yes, you will own the final product design and all associated intellectual property. Our standard agreements 
                    ensure that all deliverables and IP generated during the project are assigned to you. To protect your design,
                     we recommend:</p>
                 <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Non-Disclosure Agreements (NDAs): Signed for all parties involved in the development process. </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Patent Filings: Pursuing utility or design patents based on innovation. </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Copyrights: For specific design elements. </p>

               <p class="test"><i class="fa fa-check bn-icon" aria-hidden="true">
               </i> Trademark Registration: For branding and product names. </p>

               <p>We can guide you on best practices for IP protection relevant to your specific product.</p>

            </div>
         </div>
      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>