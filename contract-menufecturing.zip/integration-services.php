<?php include("header.php"); ?>
<main class="service-main-container">
<!-- Hero + Testimonial + Logo Section Combined -->
<section class="service-section">
   <!-- Background -->
   <div class="service-background">
      <img src="assets/image/banner-bg.jpg" alt="Hero Background" class="hero-bg-image">
   </div>
   <!-- Hero Content -->
   <div class="service-content-banner">
      <nav class="breadcrumb">
         <span class="breadcrumb-text">Services / Leading Integration Services</span>
      </nav>
      <div class="divider-line">
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/divider-line.svg" alt="Divider Line">
      </div>
      <header class="banner-header">
         <h1 class="banner-title">Leading Integration Services Provider </h1>
         <p class="banner-description">
        We deliver complete parts, sub-assembly, and assembly integration services with proven expertise.
         We handle complex assembly projects of any scale, regardless of size, shape, or quantity. 
         Our team expertly manages multi-component builds featuring specialized processes like pressure regulators,
          custom fittings, and advanced electromechanical systems. With 100+ successful projects, 
          we deliver complete solutions from initial design through final assembly. 
         </p>
      </header>
      <div class="cta-button-banner">
         <span class="cta-text-banner">Get a quote</span>
         <img src="https://static.codia.ai/custom_image/2025-07-05/131851/arrow-icon.svg" alt="Arrow" class="cta-arrow-banner">
      </div>
   </div>
   <!-- Testimonial Slider -->
   <aside class="banner-testimonial-slider">
      <div class="banner-testimonial-card">
         <div class="banner-testimonial-image">
            <img src="https://static.codia.ai/custom_image/2025-07-05/131851/card-image.png" alt="Testimonial Background">
         </div>
         <div class="banner-testimonial-content">
            <div class="banner-testimonial-text-container">
               <p class="banner-testimonial-text">I run Meli pattern works and I worked with iMac deaign, all the engineers professionals and have good quality knowledge...</p>
            </div>
            <div class="banner-testimonial-author">
               <span class="testimonial-author-name">Meli Pattern Works</span>
            </div>
            <div class="banner-testimonial-profile">
               <img src="https://static.codia.ai/custom_image/2025-07-05/131851/profile-image.png" alt="Profile" class="profile-image">
            </div>
            <div class="testimonial-dots">
               <div class="dot active"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
               <div class="dot"></div>
            </div>
         </div>
      </div>
   </aside>
   <!-- Logo Slider Inside Service Section -->
   <div class="logo-slider-inside-service">
      <div class="logo-flex-wrapper">
         <div class="banner-logo-header">
            <h2 class="banner-logo-title">TRUSTED BY LEADING BRANDS</h2>
         </div>
         <div class="banner-logo-slider">
            <div class="banner-logo-track">
               <!-- Logo Items -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <!-- Duplicate logos for infinite scroll -->
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-1.png" alt="Partner Logo 1" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-2.svg" alt="Partner Logo 2" class="partner-logo">
                  </div>
               </div>
               <div class="banner-logo-item">
                  <div class="banner-logo-wrapper">
                     <img src="https://static.codia.ai/custom_image/2025-07-05/131851/partner-logo-3.png" alt="Partner Logo 3" class="partner-logo">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="about-service-hero-section">
   <h2 class="main-title">Intergration Services  <br class="m-hidden"> From Parts To Complete Product   </h2>
   <div class="about-container">
      <div class="left-section">
         <img src="assets/image/drafting-service.png" alt="CAD Drafting" />
      </div>
      <div class="right-section">
         <p>Managing multiple suppliers, coordinating different components, and ensuring everything fits together perfectly 
            is not an job for any production team. That's where complete integration services make all the difference.
             We take care of the entire journey from individual parts to finished products, handling sourcing, sub-assembly creation,
              and final assembly under one roof. </p>

         <p>Our three-stage process transforms loose components into functional units, then smoothly 
            integrates everything into your final product. Years of experience across automotive, aerospace, electronics, 
            and medical device industries have taught us how to handle complex builds with precision. </p>

         <p>Plus, our advanced additive manufacturing capabilities mean we can create custom components 
            when standard parts won't work. iMDES delivers reliable integration solutions that eliminate your
             coordination problems and ensure every part of your product works together perfectly.</p>
      </div>
   </div>
</section>
<!-- Services Section -->
<section class="imac-services-section">
   <div class="imac-services-container">
      <h2 class="imac-services-title">Our End-to-End Integration(Assembly) Services  </h2>
      <div class="services-grid">
         <!-- <div class="service-dividers">
            <div class="divider divider-left"></div>
            <div class="divider divider-section-1"></div>
            <div class="divider divider-middle"></div>
            <div class="divider divider-section-2"></div>
            <div class="divider divider-right"></div>
            </div> -->
         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Electro-Mechanical Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">We combine electrical components and mechanical parts into unified systems. Motors meet gears, switches align with actuators - all tested for perfect interaction. iMDES ensures your hybrid systems operate smoothly, be it an industrial automation, medical devices, or advanced robotics applications.
</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting"> Precision Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">When micron-level accuracy matters, we deliver. iMDES handles delicate components, exacting tolerances, and critical alignments for industries like aerospace and medical tech. Our controlled processes and skilled technicians guarantee parts fit perfectly every time, eliminating performance issues.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Box Build Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">With box build assembly you can expect complete enclosure assemblies - done right. We install components, wiring, and plumbing into racks, cabinets, or cases with proper spacing and ventilation. Our team at iMDES tests each unit before shipment, ensuring your control systems or electronic enclosures arrive ready for immediate use.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Sub-Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">We build the building blocks. iMDES assembles modules like gear clusters, 
                control panels, or sensor arrays that later integrate into larger systems. This staged approach catches 
                issues early and simplifies final production, saving you time and reducing costly errors.</p>
         </article>

         <article class="service-card-drafting main-service">
            <div class="service-icon service-icon-1"></div>
            <h3 class="service-title-drafting">Cable & Wiring Harness Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">Organized, labeled, and routed correctly, iMDES assembles wire harnesses for vehicles, machinery,
                 and electronics using proper gauges, connectors, and protective sleeves. Our methodical approach
                  prevents electrical issues and simplifies maintenance.</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-2"></div>
            <h3 class="service-title-drafting"> Electrical & Electronic Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">From circuit boards to complete devices, we handle sensitive components with care. Our team of experts solders, tests, and validates each unit, ensuring your electronics function reliably. No matter there are prototypes or production runs, we deliver what you have expected with the exact specifications.

</p>
         </article>
         <article class="service-card-drafting">
            <div class="service-icon service-icon-3"></div>
            <h3 class="service-title-drafting">Mechanical Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">Bolts, bearings, and components - assembled with purpose. iMDES puts together physical parts for machinery, tools, and equipment. We follow strict specifications and alignment procedures so your mechanical products operate smoothly and safely. </p>
         </article>

           <article class="service-card-drafting">
            <div class="service-icon service-icon-4"></div>
            <h3 class="service-title-drafting">Custom Assembly</h3>
            <div class="service-divider"></div>
            <p class="service-description">Your design, our execution. iMDES adapts to unique requirements, whether special materials, unusual configurations, or low-volume prototypes. We problem-solve alongside you to turn concepts into functional, manufacturable products.</p>
         </article>

      </div>
   </div>
</section>
<!-- Benefits Section -->
<section class="benefits-section">
   <div class="benefits-background">
      <div class="benefits-container">
         <h2 class="benefits-title">What are the Top 5 Benefits of<br class="m-hidden">Integration (Assembly) Services?  </h2>
         <div class="benefits-grid">
            <div class="benefit-card benefit-card-1">
               <div class="benefit-icon benefit-icon-1"></div>
               <p class="benefit-text">Centralized management of component integration minimizes logistical issues, optimizes workflow efficiency, and accelerates time-to-market for finished products.</p>
            </div>
            <div class="benefit-card benefit-card-2">
               <div class="benefit-icon benefit-icon-2"></div>
               <p class="benefit-text">Standardized assembly protocols with rigorous quality control ensure dimensional accuracy, functional reliability, and consistent performance across production batches.
</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-3">
               <div class="benefit-icon benefit-icon-3"></div>
               <p class="benefit-text">Consolidated procurement and reduced handling stages lower material waste, decrease labor overhead, and improve overall manufacturing cost-efficiency.
</p>
            </div>
            <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text"> Modular service architecture accommodates variable production volumes from prototype development to full-scale commercialization with smooth capacity adjustment.</p>
            </div>
         </div>
         <div class="benefits-grid-2">
            <div class="benefit-card benefit-card-5">
               <div class="benefit-icon benefit-icon-5"></div>
               <p class="benefit-text">Integrated quality management systems maintain traceability and documentation to meet industry-specific certification requirements and safety standards.
</p>
            </div>
            <!-- <div class="benefit-card benefit-card-4">
               <div class="benefit-icon benefit-icon-4"></div>
               <p class="benefit-text">Our fast turnaround converts your 3D design files to finished parts using automated cutting and 
                forming technology, delivering quality results on schedule.</p>
            </div> -->
         </div>
      </div>
   </div>
</section>
<!-- why us section -->
<section class="features-section">
   <div class="container">
      <h2 class="benefits-title">Why Partner with iMDES <br class="m-hidden"> for Your Contract Manufacturing Needs? </h2>
      <div class="features-container">
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/100-Design-Data-Security.svg" alt="Innovation Expertise" />
               <h3>Complete Manufacturing Solutions</h3>
            </div>
            <div class="feature-back">
               <p>Since 2020, iMDES has delivered comprehensive manufacturing solutions from sheet metal fabrication to
                 injection molding, casting, and precision machining, ensuring superior quality across all production processes.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/proven-cad-expertise.svg" alt="Innovation Expertise" />
               <h3>Turnkey Project Management</h3>
            </div>
            <div class="feature-back">
               <p>We handle complete project responsibility, including mechanical, electrical, packaging,
                 and related components, delivering packaged products while you focus on sales and market growth strategies.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Access-to-international-design-drafting-standards.svg" alt="Customer-First-Thinking" />
               <h3> Proven Delivery Performance</h3>
            </div>
            <div class="feature-back">
               <p>Our established track record since 2020 demonstrates consistent on-time delivery and
                 reliable supply chain management, ensuring your production schedules remain intact and customer commitments fulfilled.</p>
            </div>
         </div>
         <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Advanced Design Capabilities</h3>
            </div>
            <div class="feature-back">
               <p>iMDES engineering team performs brilliantly well in innovative design achievements, 
                from PCB enclosures to complex tooling development, providing optimized solutions that
                 enhance product performance and manufacturability.</p>
            </div>
         </div>

        <div class="feature-box">
            <div class="feature-front">
               <img src="assets/icons/CAD-service/Quality-Commitment.svg" alt="Integrated Engineering" />
               <h3>Cost-Effective Global Sourcing</h3>
            </div>
            <div class="feature-back">
               <p>Strategic partnerships and comprehensive BOM sourcing capabilities deliver significant
                 cost savings while maintaining international quality standards, maximizing your profit margins, 
                 and competitive market positioning.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<main class="main-container-section">
   <!-- Product Development Process Section -->
   <section class="product-development-section">
      <div class="development-container">
         <h1 class="section-title-process"> The Process Of Behind Our Assembly Services</h1>
         <div class="accordion-container">
            <div class="accordion-images">
               <img src="assets/image/accordion-1.png" alt="Design & Research" class="accordion-image active" data-tab="design">
               <img src="assets/image/accordion-2.png" alt="Innovation & Strategy" class="accordion-image" data-tab="innovation">
               <img src="assets/image/accordion-3.png" alt="Product Design" class="accordion-image" data-tab="product">
               <img src="assets/image/accordion-1.png" alt="Engineering" class="accordion-image" data-tab="engineering">
               <img src="assets/image/accordion-2.png" alt="Prototyping" class="accordion-image" data-tab="prototyping">
            </div>
            <div class="accordion-content">
               <div class="accordion-item active" data-tab="design">
                  <div class="accordion-header">
                     <span class="step-number">01.</span>
                     <h3 class="step-title">Component Inspection & Preparation</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Every part undergoes strict and solid dimensional checks, material verification,
                         and surface quality assessment. We catalog components using barcode tracking, ensuring full traceability.
                          Non-conforming items are quarantined immediately, maintaining our zero-defect entry standard for all 
                          assembly processes.</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="innovation">
                  <div class="accordion-header">
                     <span class="step-number">02.</span>
                     <h3 class="step-title">Precision Sub-Assembly</h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Specialized technicians assemble modules using calibrated tools and jigs. Each sub-unit (gearboxes, PCBs, etc.) receives functional testing before progression. This staged approach catches 92% of potential issues early, reducing final-stage rework by 40%.
</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="product">
                  <div class="accordion-header">
                     <span class="step-number">03.</span>
                     <h3 class="step-title">Quality Verification </h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Sub-assemblies enter our metrology lab for 3D scanning, torque validation, and electrical testing. Automated optical inspection (AOI) compares components against digital twins. Only units passing all 17 checkpoint criteria proceed to final integration.
 </p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="engineering">
                  <div class="accordion-header">
                     <span class="step-number">04.</span>
                     <h3 class="step-title">Final Integration </h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Master technicians assemble tested sub-units into complete systems using robotic assist arms for heavy components. Each connection undergoes real-time sensor monitoring (vibration, thermal, pressure) to ensure perfect mating and alignment.

</p>
                  </div>
               </div>
               <div class="accordion-item" data-tab="prototyping">
                  <div class="accordion-header">
                     <span class="step-number">05.</span>
                     <h3 class="step-title">Performance Testing </h3>
                     <div class="arrow-icon"></div>
                  </div>
                  <div class="accordion-body">
                     <p>Finished products endure 72-hour stress cycles (thermal, load, endurance) simulating 5 years of operation. We generate certified test reports with 200+ data points before approving shipment, guaranteeing field-ready reliability.</p>
                  </div>
               </div>

            </div>
         </div>
      </div>
   </section>
</main>
<!-- FAQ Section -->
<section class="faq-section">
   <div class="faq-container">
      <div class="faq-content">
         <h2 class="faq-title">Frequently Asked<br>Questions Answered</h2>
         <div class="faq-contact">
            <span class="faq-contact-text">Have any other questions?</span>
            <a href="#" class="faq-contact-link">Contact Us</a>
         </div>
      </div>
      <div class="faq-accordion">
         <div class="faq-item active">
            <div class="faq-question">
               <span class="faq-question-text">What is rapid tooling? </span>
               <div class="faq-icon">
                  <div class="faq-icon-closed"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Rapid tooling is a method of quickly creating molds, dies, or other manufacturing tools, primarily 
                for prototyping or low-volume production. It leverages additive manufacturing (3D printing) and 
                high-speed machining to produce tooling much faster and often more affordably than conventional methods.</p>
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">How does rapid tooling differ from traditional tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p>Rapid tooling differs from traditional tooling primarily in its speed, cost, and typical volume suitability. 
                Traditional tooling involves lengthy, expensive processes like EDM of hard metals for high-volume, durable molds.
                 Rapid tooling utilizes faster, often additive methods and less durable materials, ideal for quick iterations, 
                 prototypes, or low to medium production runs.</p> 
            </div>
         </div>
         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What materials can be used in rapid tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
               <p> Rapid tooling can use a variety of materials, including polymers (plastics), composites, and even some metals. 
                Common materials include photopolymers, ABS, nylon, and various resins for 3D printed molds, as well as softer 
                aluminum alloys or high-density epoxies for machined tools.</p>
            </div>
         </div>

        <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">What types of molds are used in rapid tooling?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Rapid tooling employs various mold types, including injection molds, vacuum forming molds, blow molds, 
                    and soft tooling inserts. These molds can be 3D printed directly (e.g., plastic molds for silicone 
                    casting or short-run injection molding) or produced by rapidly machining softer metals or tooling boards.</p>
            </div>
         </div>

         <div class="faq-item">
            <div class="faq-question">
               <span class="faq-question-text">Is rapid tooling suitable for low-volume production?</span>
               <div class="faq-icon">
                  <div class="faq-icon-open"></div>
               </div>
            </div>
            <div class="faq-answer">
                <p>Yes, rapid tooling is highly suitable for low-volume production. Its speed and lower cost per tool make it an 
                    excellent choice for producing hundreds or thousands of parts before committing to expensive, high-volume 
                    traditional tooling, or for bridge production between prototyping and mass manufacturing.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- contact section end -->
<script>
   document.addEventListener('DOMContentLoaded', function() {
   const slider = document.querySelector('.services-slider');
   const prevBtn = document.querySelector('.services-nav img:first-child');
   const nextBtn = document.querySelector('.services-nav img:last-child');
   
   if (slider && prevBtn && nextBtn) {
       let scrollAmount = 0;
       const slideWidth = 490; // slide width + gap
       
       // Next button click
       nextBtn.addEventListener('click', function() {
           scrollAmount += slideWidth;
           if (scrollAmount > slider.scrollWidth - slider.clientWidth) {
               scrollAmount = 0;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
       
       // Previous button click
       prevBtn.addEventListener('click', function() {
           scrollAmount -= slideWidth;
           if (scrollAmount < 0) {
               scrollAmount = slider.scrollWidth - slider.clientWidth;
           }
           slider.scrollTo({
               left: scrollAmount,
               behavior: 'smooth'
           });
       });
   } else {
       console.error('Slider or navigation buttons are missing in the DOM.');
   }
   });
   
   // Process accordion
   const processHeaders = document.querySelectorAll('.process-header');
   
   processHeaders.forEach(header => {
   header.addEventListener('click', function () {
       const description = this.nextElementSibling;
       const arrow = this.querySelector('img');  // Ensure this targets the correct element
   
       if (description.style.display === 'none' || !description.style.display) {
           description.style.display = 'block';
           arrow.style.transform = 'rotate(180deg)';
       } else {
           description.style.display = 'none';
           arrow.style.transform = 'rotate(0deg)';
       }
   });
   });
   
   window.addEventListener('scroll', function () {
   const header = document.getElementById('mainHeader');
   if (window.scrollY > 50) {
     header.classList.add('sticky');
   } else {
     header.classList.remove('sticky');
   }
   });
   
   // faq js
   document.addEventListener('DOMContentLoaded', function() {
   // FAQ Accordion functionality
   const faqItems = document.querySelectorAll('.faq-item');
   
   faqItems.forEach(item => {
   const question = item.querySelector('.faq-question');
   
   question.addEventListener('click', () => {
     // Close all other items
     faqItems.forEach(otherItem => {
       if (otherItem !== item) {
         otherItem.classList.remove('active');
       }
     });
     
     // Toggle current item
     item.classList.toggle('active');
   });
   });
   
   // Smooth scrolling for contact link
   const contactLink = document.querySelector('.faq-contact-link');
   if (contactLink) {
   contactLink.addEventListener('click', function(e) {
     e.preventDefault();
     // Add your contact form or modal logic here
     console.log('Contact us clicked');
   });
   }
   
   // Add intersection observer for animations (optional enhancement)
   const observerOptions = {
   threshold: 0.1,
   rootMargin: '0px 0px -50px 0px'
   };
   
   const observer = new IntersectionObserver((entries) => {
   entries.forEach(entry => {
     if (entry.isIntersecting) {
       entry.target.style.opacity = '1';
       entry.target.style.transform = 'translateY(0)';
     }
   });
   }, observerOptions);
   
   // Observe sections for fade-in animation
   const sections = document.querySelectorAll('section');
   sections.forEach(section => {
   section.style.opacity = '0';
   section.style.transform = 'translateY(20px)';
   section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
   observer.observe(section);
   });
   
   // Handle window resize for responsive adjustments
   let resizeTimer;
   window.addEventListener('resize', function() {
   clearTimeout(resizeTimer);
   resizeTimer = setTimeout(function() {
     // Add any resize-specific logic here if needed
     console.log('Window resized');
   }, 250);
   });  
   }); 
</script>
<script src="js/slider.js"></script>
<script src="js/slider-testimonial.js"></script>
<script src="js/testimonial-slider.js"></script>
<script src="js/logo-slider.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/banner-logo-slider.js"></script>
<?php include("footer.php"); ?>